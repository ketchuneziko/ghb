#!/usr/bin/env python3
# PNG -> цветная ASCII-карта для проверки композиции (NEAREST, чтобы не мылить пиксель-арт)
#   python3 ascii.py file.png [cols] [x0 y0 x1 y1]   -- кроп в координатах PNG
import sys, colorsys
from PIL import Image

PAL = {'#': 0}

def ch_for(r, g, b):
    h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    if v < 0.09:
        return ' '
    if s < 0.16:
        return '.' if v < 0.4 else ('o' if v < 0.75 else 'O')
    deg = h * 360
    if deg < 15 or deg >= 335: ch = 'R'
    elif deg < 45: ch = 'P'
    elif deg < 70: ch = 'Y'
    elif deg < 160: ch = 'G'
    elif deg < 200: ch = 'C'
    elif deg < 265: ch = 'B'
    else: ch = 'M'
    if v < 0.42: ch = ch.lower()
    elif v > 0.85: ch = ch.upper()
    return ch

def show(path, cols=110, crop=None):
    im = Image.open(path).convert('RGB')
    if crop:
        im = im.crop(crop)
    W, H = im.size
    rows = max(1, round(cols * H / W * 0.5))
    im2 = im.resize((cols, rows), Image.NEAREST)
    px = im2.load()
    print(f'--- {path} {crop or ""} ({W}x{H}) ---')
    for y in range(rows):
        print(''.join(ch_for(*px[x, y]) for x in range(cols)))

if __name__ == '__main__':
    p = sys.argv[1]
    c = int(sys.argv[2]) if len(sys.argv) > 2 else 110
    crop = tuple(int(v) for v in sys.argv[3:7]) if len(sys.argv) >= 7 else None
    show(p, c, crop)
