const puppeteer=require('puppeteer');
const OUT=[]; const log=(...a)=>{const s=a.join(' ');OUT.push(s);console.log(s);};
(async()=>{
  const b=await puppeteer.launch({args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=swiftshader','--mute-audio']});
  const p=await b.newPage(); p.on('pageerror',e=>log('!! PAGEERROR:',e.message));
  await p.setViewport({width:420,height:760});
  await p.goto('http://127.0.0.1:8711/index.html',{waitUntil:'load'});
  await p.waitForFunction('typeof W!=="undefined"&&W>0');
  const ev=(f,...a)=>p.evaluate(f,...a);
  // 1. загрузка -> рабочий стол
  await p.waitForFunction('G.state==="title"',{timeout:30000});
  await p.keyboard.press('Space'); await new Promise(r=>setTimeout(r,300));
  log('состояние после входа:', await ev('G.state'));
  // 2. меню Пуск -> КОМАНДНАЯ СТРОКА (тапаем по кнопке «Пуск», затем по пункту)
  await ev(`(()=>{const d=G.screens.desktop,r=d.startRect;d.tap(r.x+r.w/2,r.y+r.h/2)})()`);
  await new Promise(r=>setTimeout(r,200));
  const items = await ev('G.screens.desktop.startItems().map((x,i)=>i+":"+x.t)');
  log('меню Пуск:', items.join(' | '));
  await ev(`(()=>{const d=G.screens.desktop,s=d.startRectItems,i=G.screens.desktop.startItems().findIndex(x=>x.t==='КОМАНДНАЯ СТРОКА');d.tap(s.x+s.w/2, s.y+4+i*14+6)})()`);
  await new Promise(r=>setTimeout(r,250));
  log('окно терминала:', await ev('G.win&&G.win.kind'));
  // 3. печатаем help и he
  for(const k of 'he') await p.keyboard.press('Key'+k.toUpperCase());
  await p.keyboard.press('Enter'); await new Promise(r=>setTimeout(r,150));
  log('команда:', JSON.stringify(await ev('G.win.data.cmd')), 'строк:', await ev('G.win.data.lines.length'));
  log('последняя строка:', await ev('G.win.data.lines[G.win.data.lines.length-1].t'));
  // 4. love -> побочный эффект
  for(const k of 'love') await p.keyboard.press('Key'+k.toUpperCase());
  await p.keyboard.press('Enter'); await new Promise(r=>setTimeout(r,150));
  log('love:', await ev('G.win.data.lines.slice(-3).map(l=>l.t).join(" | ")'));
  log('частиц на экране:', await ev('FX.length>0'));
  // 5. закрыть терминал, открыть настройки, щёлкнуть по «эффекты»
  await p.keyboard.press('Escape'); await new Promise(r=>setTimeout(r,150));
  log('после ESC окно:', await ev('!!G.win'));
  await ev('openSettings()'); await new Promise(r=>setTimeout(r,150));
  const before=await ev('G.crt');
  await ev(`(()=>{const r=Win.inner(G.win);G.screens.desktop.tap(r.x+40,r.y+8)})()`);
  await new Promise(r=>setTimeout(r,120));
  log('эффекты:', before, '->', await ev('G.crt'));
  await ev('Win.close()');
  await new Promise(r=>setTimeout(r,150));
  // 6. звезды в меню
  await ev(`(()=>{const d=G.screens.desktop,r=d.startRect;d.tap(r.x+r.w/2,r.y+r.h/2)})()`);
  await new Promise(r=>setTimeout(r,250));
  await ev('G.screens.desktop.startOpen=false');
  // 7. письмо
  await ev('G.hearts=new Array(NH).fill(true); goNow("letter")');
  await new Promise(r=>setTimeout(r,600));
  log('экран письма:', await ev('G.state'));
  // 8. сохранение
  await ev('save()');
  const saved=await ev('(()=>{try{return !!localStorage.getItem("printILY3")}catch(e){return "err"}})()');
  log('сохранение в localStorage:', saved);
  const ext=await ev('document.querySelectorAll("script[src],link[href],img[src^=http]").length');
  log('внешних ресурсов:', ext);
  await b.close();
  log(fs=OUT.length?'E2E ГОТОВ':'');
})();
