// Сквозной прогон HeartOS в настоящем браузере: загрузка -> 5 эпизодов -> 8 сердец -> финал.
const puppeteer = require('puppeteer');
const out = []; let bad = 0;
const log = (...a) => { const s = a.join(' '); out.push(s); console.log(s); };
const check = (name, ok, extra) => { if (!ok) { bad++; log('  ✗ ' + name + (extra ? ' → ' + extra : '')); } else log('  ✓ ' + name + (extra ? ' → ' + extra : '')); };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  const b = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=swiftshader', '--mute-audio'] });
  const p = await b.newPage();
  p.on('pageerror', e => { bad++; log('!! PAGEERROR:', e.message); });
  p.on('console', m => { if (/error/i.test(m.text())) log('!! CONSOLE:', m.text()); });
  await p.setViewport({ width: 420, height: 760 });
  await p.goto('http://127.0.0.1:8711/index.html', { waitUntil: 'load' });
  await p.waitForFunction('typeof W!=="undefined"&&W>0', { timeout: 20000 });
  const ev = (f, ...a) => p.evaluate(f, ...a);
  const state = () => ev('G.state');
  const openMap = async () => {
    for (let i = 0; i < 3; i++) {
      if (await ev('G.win&&G.win.kind') === 'map') return true;
      await ev('G.screens.desktop.openMapWin()'); await sleep(320);
    }
    return await ev('G.win&&G.win.kind') === 'map';
  };
  const skipIntro = async () => {
    for (let i = 0; i < 60 && await state() !== 'level'; i++) { await p.keyboard.press('Space'); await sleep(70); }
  };

  log('— загрузка —');
  check('старт в boot', await state() === 'boot');
  const bootTxt = await ev(`G.screens.boot.li>=0`);
  for (let i = 0; i < 40 && !(await ev('G.screens.boot.done')); i++) { await p.keyboard.press('Space'); await sleep(120); }
  check('загрузка дошла до «Готово»', await ev('G.screens.boot.done'));
  await p.keyboard.press('Space'); await sleep(500);
  check('пробел -> рабочий стол', await state() === 'desktop');
  const icons = await ev('G.screens.desktop.icons.map(i=>i.name)');
  check('на рабочем столе 4 программы из ТЗ', ['ШИФР.exe', 'ПРОГРЕСС.exe', 'КОМАНДНАЯ СТРОКА', 'ПАРАМЕТРЫ'].every(n => icons.includes(n)), icons.join(' '));
  check('статус-строка 0 / 8', await ev('storyDone()') === 0);

  log('— карта —');
  await openMap(); await sleep(200);
  check('окно ПРОГРЕСС.exe', await ev('G.win&&G.win.kind') === 'map');
  const tabs = await ev('G.win.mapRects.tabs');
  await ev(`G.screens.desktop.tap(${tabs[1].x+5},${tabs[1].y+5})`); await sleep(250);
  check('вкладка БОНУС', await ev('G.win.tab') === 1, (await ev('G.win.mapRects.nodes.length')) + ' узлов');
  await ev(`G.screens.desktop.tap(${tabs[0].x+5},${tabs[0].y+5})`); await sleep(250);
  check('вкладка СЮЖЕТ', await ev('G.win.tab') === 0, (await ev('G.win.mapRects.nodes.length')) + ' узлов');
  check('5 сюжетных + финал', await ev('G.win.mapRects.nodes.length') === 6);

  log('— эпизод 1: ШИФР —');
  let n0 = (await ev('G.win.nodesXY')).find(n => n.i === 0);
  await ev(`G.screens.desktop.tap(${n0.x},${n0.y})`); await sleep(300);
  await skipIntro();
  check('уровень 1 запущен', await state() === 'level', 'сцена ' + await ev('LEVELS[0].scene'));
  await ev(`(()=>{const L=LEVELS[0];L.rot(1);L.readIt();})()`); await sleep(1400);
  check('сердце 1 выдано', await ev('G.hearts[0]') === true, await state());
  await p.keyboard.press('Space'); await sleep(300);
  for (let i = 0; i < 50 && await state() !== 'desktop'; i++) { await p.keyboard.press('Space'); await sleep(90); }
  check('вернулись на рабочий стол', await state() === 'desktop');
  check('счётчик 1 / 8', await ev('storyDone()') === 1);

  log('— эпизод 2: РИТМ СЕРДЦА —');
  await openMap(); await sleep(200);
  n0 = (await ev('G.win.nodesXY')).find(n => n.i === 1);
  await ev(`G.screens.desktop.tap(${n0.x},${n0.y})`); await sleep(300);
  await skipIntro();
  check('уровень 2 запущен', await state() === 'level');
  // играем по-настоящему: жмём ровно в доли
  await ev(`(()=>{  // авто-игра в такт: жмём в том же кадре, когда сменилась доля
    const L=LEVELS[1]; let last=0, on=true; window.__rh=[];
    L.__auto=setInterval(()=>{ if(!on || G.state!=='level'){ if(G.state!=='level') on=false; } },50);
    const loop=()=>{ if(!on) return;
      if(L.beat!==last){ last=L.beat;
        if(RTH.pattern[(L.beat-1)%RTH.pattern.length]==='x'){
          window.__rh.push(L.beat+':'+L.offBeat().toFixed(3)); L.tapNow();
        } }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  })()`);
  for (let i = 0; i < 200 && !(await ev('G.hearts[1]')); i++) await sleep(100);
  await ev('(()=>{const L=LEVELS[1];if(L&&L.__auto) clearInterval(L.__auto);})()');
  const rt = await ev('(()=>{const L=LEVELS[1];return "hit="+L.hit+" miss="+L.miss+" beat="+L.beat+" | "+String(window.__rh);})()');
  check('сердце 2 выдано', await ev('G.hearts[1]') === true, rt);
  await p.keyboard.press('Space'); await sleep(300);
  for (let i = 0; i < 50 && await state() !== 'desktop'; i++) { await p.keyboard.press('Space'); await sleep(90); }

  log('— эпизод 3: ВОСПОМИНАНИЯ —');
  await openMap(); await sleep(200);
  n0 = (await ev('G.win.nodesXY')).find(n => n.i === 2);
  await ev(`G.screens.desktop.tap(${n0.x},${n0.y})`); await sleep(300);
  await skipIntro();
  check('уровень 3 запущен', await state() === 'level');
  await ev(`(()=>{const L=LEVELS[2];L.memNext();L.stop=1;L.memNext();L.stop=2;L.memNext();L.k_main(' ');})()`);
  await sleep(1500);
  check('сердца 3 и 4 выданы', await ev('G.hearts[2]') === true, 'счётчик ' + await ev('storyDone()'));
  await p.keyboard.press('Space'); await sleep(300);
  for (let i = 0; i < 50 && await state() !== 'desktop'; i++) { await p.keyboard.press('Space'); await sleep(90); }

  log('— эпизод 4: ЛАБИРИНТ И ДОЖДЬ —');
  await openMap(); await sleep(200);
  n0 = (await ev('G.win.nodesXY')).find(n => n.i === 3);
  await ev(`G.screens.desktop.tap(${n0.x},${n0.y})`); await sleep(300);
  await skipIntro();
  check('уровень 4 запущен', await state() === 'level');
  await ev(`(()=>{  // идём по волновому поиску
    const L=LEVELS[3], prev={}, q=[[1,1]]; prev['1,1']=null;
    while(q.length){ const [r,c]=q.shift();
      if(r===L.warm.r&&c===L.warm.c) break;
      for(const [dr,dc] of [[0,1],[0,-1],[1,0],[-1,0]]){
        const nr=r+dr,nc=c+dc,k=nr+','+nc;
        if(nr<0||nc<0||nr>=MAZ.rows||nc>=MAZ.cols||k in prev||L.walls[nr][nc]) continue;
        prev[k]=r+','+c; q.push([nr,nc]);
      } }
    let k=L.warm.r+','+L.warm.c, path=[];
    while(prev[k]){ const p=prev[k].split(',').map(Number), n=k.split(',').map(Number);
      path.unshift([n[1]-p[1], n[0]-p[0]]); k=p.join(','); }
    path.forEach(([dc,dr])=>L.mv(dc,dr));
    window.__mazeDebug = 'шагов '+path.length+' финиш '+L.cx+','+L.cy+' цель '+L.warm.r+','+L.warm.c+' сцена '+L.scene;
  })()`);
  log('   ' + await ev('window.__mazeDebug'));
  await sleep(1600);
  check('сердца 5 и 6 выданы', await ev('G.hearts[3]') === true, 'счётчик ' + await ev('storyDone()') + ' ' + await ev('window.__mazeDebug'));
  await p.keyboard.press('Space'); await sleep(300);
  for (let i = 0; i < 50 && await state() !== 'desktop'; i++) { await p.keyboard.press('Space'); await sleep(90); }

  log('— эпизод 5: ИСПРАВЛЕНИЕ КОДА —');
  await openMap(); await sleep(200);
  n0 = (await ev('G.win.nodesXY')).find(n => n.i === 4);
  await ev(`G.screens.desktop.tap(${n0.x},${n0.y})`); await sleep(300);
  await skipIntro();
  check('уровень 5 запущен', await state() === 'level');
  await ev(`(()=>{const L=LEVELS[4];for(let i=0;i<3;i++){L.pick=COD.tasks[L.step].ok;L.apply();}})()`);
  await sleep(1500);
  check('сердца 7 и 8 выданы', await ev('G.hearts[4]') === true);
  check('счётчик 8 / 8', await ev('storyDone()') === 8, String(await ev('storyDone()')));
  check('финал открылся', await ev('finaleReady()') === true);
  await p.keyboard.press('Space'); await sleep(300);
  for (let i = 0; i < 50 && await state() !== 'desktop'; i++) { await p.keyboard.press('Space'); await sleep(90); }

  log('— финал —');
  await openMap(); await sleep(200);
  n0 = (await ev('G.win.nodesXY')).find(n => n.i === 13);
  await ev(`G.screens.desktop.tap(${n0.x},${n0.y})`); await sleep(600);
  check('экран ALL HEARTS RESTORED', await state() === 'restored', String(await ev('G.state')));
  await sleep(2600);
  check('восемь сердец зажглись', await ev('G.screens.restored.n') === 8);
  await p.keyboard.press('Space'); await sleep(600);
  check('комната памяти открылась', await state() === 'memroom');
  // смотрим все три воспоминания
  for (let i = 0; i < 3; i++) {
    await ev(`(()=>{const s=G.screens.memroom;const g=s.geom();const p=g.photos[${i}];s.tap(p.x+3,p.y+3);})()`);
    await sleep(2600);
    for (let k = 0; k < 3 && await ev('G.screens.memroom.open') >= 0; k++) { await ev(`G.screens.memroom.tap(5,5)`); await sleep(400); }
  }
  check('все три воспоминания открыты', await ev('MR.count()') === 3, String(await ev('MR.count()')));
  check('подпись последнего воспоминания', (await ev('MR_MEM[2].cap')) === '03:17');
  const ex = await ev('(()=>{const s=G.screens.memroom;const e=s.geom().exe;return {x:e.x+2,y:e.y+2};})()');
  await ev(`G.screens.memroom.tap(${ex.x},${ex.y})`); await sleep(700);
  check('ФИНАЛ.exe запустил финал', await state() === 'finale', String(await state()));
  check('восемь сердец летят', await ev('G.screens.finale.pts.length') === 8);
  await sleep(4800);
  check('слились в одно и бьётся', await ev('G.screens.finale.phase') === 'beat', await ev('G.screens.finale.phase'));
  await sleep(3600);
  check('появилось письмо', await ev('G.screens.finale.phase') === 'text');
  for (let i = 0; i < 200 && await ev('G.screens.finale.btn') !== 0; i++) await sleep(150);
  check('письмо дописано', await ev('G.screens.finale.chars') >= await ev('G.screens.finale.totalChars()'));
  for (let i = 0; i < 40 && await ev('G.screens.finale.phase') === 'text'; i++) { await p.keyboard.press('Space'); await sleep(120); }
  check('первый вопрос', await ev('G.screens.finale.phase') === 'ask1', await ev('FIN.ask1'));
  await sleep(900);
  const r1 = await ev('G.screens.finale.rYes');
  const o1 = await ev('G.screens.finale.rOfc');
  check('две кнопки ДА и КОНЕЧНО', !!r1 && !!o1);
  check('подпись BEYOND', (await ev('FIN.sign')) === 'TO INFINITY AND BEYOND');
  check('мягкий первый вопрос', (await ev('FIN.ask1')) === 'Ты останешься со мной?');
  await ev(`G.screens.finale.tap(${o1.x + o1.w/2}, ${o1.y + o1.h/2})`); await sleep(600);
  check('КОНЕЧНО на первом вопросе запомнен', await ev('G.screens.finale.ans') === 'ofc');
  check('второй вопрос', await ev('G.screens.finale.phase') === 'ask2', await ev('FIN.ask2'));
  await sleep(900);
  const r2 = await ev('G.screens.finale.rYes');
  await ev(`G.screens.finale.tap(${r2.x + r2.w/2}, ${r2.y + r2.h/2})`); await sleep(1200);
  check('финальная сцена', await ev('G.screens.finale.phase') === 'end');
  check('второй вопрос мягче', (await ev('FIN.ask2')) === 'Давай продолжим это вместе?');
  check('нет варианта Нет', await ev('(()=>{const f=FIN;return !f.no && !f.noYes && !f.nope;})()'));
  check('последний выбор сохранён', await ev('G.screens.finale.ans') === 'yes');
  check('реакция на КОНЕЧНО', (await ev('FIN.reactOfc')) === 'Хорошо. Тогда можешь не уходить.');

  log('— терминал —');
  await ev(`(()=>{G.screens.finale.rAgain && G.screens.finale.tap(G.screens.finale.rAgain.x+2, G.screens.finale.rAgain.y+2);})()`);
  await sleep(600);
  check('кнопка «пройти заново» сбросила прогресс', await ev('storyDone()') === 0);
  await ev('openTerm()'); await sleep(350);
  for (const k of 'help') await p.keyboard.press('Key' + k.toUpperCase());
  await p.keyboard.press('Enter'); await sleep(300);
  const help = await ev('G.win.data.lines.map(l=>l.t).join(" ").replace(/\\s+/g," ")');
  check('help: справка с архивом', help.indexOf('ДОСТУПНЫЕ КОМАНДЫ:') >= 0 && help.indexOf('archive — открыть архив') >= 0);
  for (const k of 'love') await p.keyboard.press('Key' + k.toUpperCase());
  await p.keyboard.press('Enter'); await sleep(300);
  let love = await ev('G.win.data.lines.map(l=>l.t).join(" ").replace(/\\s+/g," ")');
  check('love: запуск', love.indexOf('ВЫПОЛНЕНИЕ КОМАНДЫ love') >= 0);
  for (let i = 0; i < 60 && love.indexOf('Но, кажется, ей нравится.') < 0; i++) { await sleep(120); love = await ev('G.win.data.lines.map(l=>l.t).join(" ").replace(/\\s+/g," ")'); }
  check('love: слишком много нежности', love.indexOf('УРОВЕНЬ НЕЖНОСТИ СЛИШКОМ ВЫСОК.') >= 0);
  check('love: и она ей нравится', love.indexOf('Но, кажется, ей нравится.') >= 0);
  check('love: эффекты на экране', (await ev('LOVEFX.length')) > 0, (await ev('LOVEFX.length')) + ' частиц');
  for (const k of 'sudo') { await p.keyboard.press('Key' + k.toUpperCase()); }
  await p.keyboard.press('Space');
  for (const k of 'love') await p.keyboard.press('Key' + k.toUpperCase());
  await p.keyboard.press('Enter'); await sleep(400);
  const sudo = await ev('G.win.data.lines.map(l=>l.t).join(" ").replace(/\\s+/g," ")');
  check('sudo love: разрешено', sudo.indexOf('разрешено') >= 0);
  for (const k of 'hearts') await p.keyboard.press('Key' + k.toUpperCase());
  await p.keyboard.press('Enter'); await sleep(300);
  const hh = await ev('G.win.data.lines.map(l=>l.t).join(" ").replace(/\\s+/g," ")');
  check('hearts: строка архива', hh.indexOf('АРХИВ: 0 / 5') >= 0, hh.slice(-90));
  for (const k of 'zzz') await p.keyboard.press('Key' + k.toUpperCase());
  await p.keyboard.press('Enter'); await sleep(300);
  const unk = await ev('G.win.data.lines.map(l=>l.t).join(" ").replace(/\\s+/g," ")');
  check('неизвестная команда', unk.indexOf('КОМАНДА НЕ НАЙДЕНА.') >= 0);
  await sleep(200);
  for (const k of 'maria') { await p.keyboard.press('Key' + k.toUpperCase()); await sleep(40); }
  await p.keyboard.press('Enter'); await sleep(1200);
  const mar = await ev('G.win.data.lines.map(l=>l.t).join(" ").replace(/\\s+/g," ")');
  check('пасхалка maria', mar.indexOf('МАРИЯ НАЙДЕНА.') >= 0, mar.slice(-70));
  await p.keyboard.press('Escape'); await sleep(300);

  log('— бонус не считается в главной линии —');
  await ev('startLevel(6)'); await skipIntro();
  check('бонус запустился', await state() === 'level', await ev('LEVELS[6].name'));
  await ev('LEVELS[6].meter=150'); await sleep(600);
  check('бонусное сердце получено', await ev('G.hearts[6]') === true);
  check('главный счётчик не изменился', await ev('storyDone()') === 0, String(await ev('storyDone()')));
  await p.keyboard.press('Space'); await sleep(300);
  for (let i = 0; i < 50 && await state() !== 'desktop'; i++) { await p.keyboard.press('Space'); await sleep(90); }

  log('— сохранение и автономность —');
  await ev('save()');
  const saved = await ev(`(()=>{try{return JSON.parse(localStorage.getItem("printILY3")).h.filter(Boolean).length}catch(e){return "err"}})()`);
  check('прогресс сохранён', saved >= 1, String(saved));
  const ext = await ev('document.querySelectorAll("script[src],link[href],img[src^=http],iframe").length');
  check('внешних ресурсов нет', ext === 0, String(ext));
  const size = (await p.content()).length;
  check('страница собралась', size > 300000, Math.round(size / 1024) + ' КБ HTML');

  await b.close();
  log(bad ? `\n❌ провалов: ${bad}` : '\n✅ СКВОЗНОЙ ПРОГОН ПРОЙДЕН');
  process.exit(bad ? 1 : 0);
})().catch(e => { console.error('FAIL', e.stack); process.exit(1); });
