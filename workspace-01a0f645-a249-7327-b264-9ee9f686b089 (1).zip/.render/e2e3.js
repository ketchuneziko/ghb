// Сквозной прогон раздела HEART ARCHIVE: реальные клики и клавиши.
const puppeteer = require('puppeteer');

const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  const b = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=swiftshader', '--mute-audio'] });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  await p.setViewport({ width: 420, height: 760, deviceScaleFactor: 1 });
  await p.goto('http://127.0.0.1:8711/index.html', { waitUntil: 'load' });
  await p.waitForFunction('typeof W!=="undefined" && W>0');
  await sleep(400);
  let fail = 0;
  const hearts0 = await p.evaluate(() => G.hearts.slice());
  const ok = (cond, msg) => { if (cond) console.log('  ✓', msg); else { console.log('  ✗', msg); fail++; } };

  // 1. рабочий стол: иконка архива
  await p.evaluate(() => { goNow('desktop'); });
  const rect = await p.evaluate(() => { const r = cv.getBoundingClientRect(); return { l: r.left, t: r.top, w: r.width, h: r.height, W, H }; });
  SC = { x: rect.w / rect.W, y: rect.h / rect.H };
  const click = async (x, y) => { await p.mouse.click(x * SC.x, y * SC.y); };
  await sleep(300);
  const icon = await p.evaluate(() => {
    const ic = G.screens.desktop.icons.find(i => i.kind === 'arch');
    if (!ic) return null;
    return { x: ic.tx, y: ic.ty, name: ic.name };
  });
  ok(!!icon, 'на рабочем столе есть АРХИВ.exe' + (icon ? ' (' + icon.name + ' @' + Math.round(icon.x) + ',' + Math.round(icon.y) + ')' : ''));
  console.log('    канвас', JSON.stringify(rect), 'масштаб', JSON.stringify(SC));
  if (icon) console.log('    проверка попадания:', JSON.stringify(await p.evaluate(({x,y}) => { const i = G.screens.desktop.iconAt(x,y); return i>=0 ? G.screens.desktop.icons[i].name : 'мимо'; }, {x:icon.x,y:icon.y})));

  // 2. открыть окно архива двойным кликом
  await click(icon.x, icon.y);
  await sleep(450);
  ok(await p.evaluate(() => !!(G.win && G.win.kind === 'arch')), 'окно HEART ARCHIVE открылось');
  const intro = await p.evaluate(() => ({ page: G.win.data.page, all: AR.doneCount() >= ARCH_N }));
  ok(intro.page === 0, 'открылась страница-вступление');
  await p.keyboard.press('Space');                 // ОТКРЫТЬ АРХИВ
  await sleep(250);
  ok(await p.evaluate(() => G.win.data.page === 1), 'кнопка ОТКРЫТЬ АРХИВ открыла список');
  const st = await p.evaluate(() => ({ rows: (G.win.data.rows || []).length, title: G.win.title }));
  ok(st.rows === 5, 'в окне 5 игр (' + st.rows + ')');
  ok(/HEART ARCHIVE/.test(st.title), 'заголовок окна: ' + st.title);

  // 3. клавиатурная навигация по играм
  await p.keyboard.press('ArrowDown');
  await p.keyboard.press('ArrowDown');
  await sleep(150);
  ok(await p.evaluate(() => G.win.data.sel === 2), 'стрелки выбирают третью игру');
  await p.keyboard.press('Tab');
  await sleep(120);
  ok(await p.evaluate(() => G.win.data.tab === 1), 'Tab переключает вкладку статистики');
  await p.keyboard.press('Tab');
  await sleep(120);

  // 4. запустить игру 03 (музыка) по клику по строке
  const row = await p.evaluate(() => {
    const r = (G.win.data.rows || []).find(x => x.i === 2);
    return r ? { x: r.x + r.w / 2, y: r.y + r.h / 2 } : null;
  });
  await click(row.x, row.y);
  await sleep(400);
  ok(await p.evaluate(() => G.state === 'arcard'), 'открылась карточка-интро');
  await sleep(500);
  for (let i = 0; i < 8 && await p.evaluate(() => G.state) !== 'arlevel'; i++) {   // НАЧАТЬ
    await p.keyboard.press('Space');
    await sleep(320);
  }
  ok(await p.evaluate(() => !G.win), 'окно архива закрылось при запуске игры');
  ok(await p.evaluate(() => G.state === 'arlevel'), 'карточка открыла уровень' + (await p.evaluate(() => ' — состояние: ' + G.state + ', t=' + (G.screens[G.state] ? G.screens[G.state].t.toFixed(2) : '—'))));

  // 5. пройти первый раунд настоящими клавишами 1..7
  const seq = await p.evaluate(() => { const L = ARCH_LEVELS.music; return L.seq.slice(); });
  // дождаться конца прослушивания
  await p.waitForFunction(`ARCH_LEVELS.music.scene==='repeat'`, { timeout: 15000 });
  for (const k of seq) { await p.keyboard.press(String(k + 1)); await sleep(90); }
  ok(await p.evaluate(() => ARCH_LEVELS.music.rnd === 1), 'раунд 1 пройден, начался раунд 2');

  // 6. ошибиться и убедиться, что прогресс не сброшен полностью
  await p.waitForFunction(`ARCH_LEVELS.music.scene==='repeat'`, { timeout: 15000 });
  const before = await p.evaluate(() => { const L = ARCH_LEVELS.music; return { rnd: L.rnd, len: L.seq.length }; });
  const wrongKey = String(((seq[0] + 1) % 7) + 1);
  await p.keyboard.press(wrongKey);
  await sleep(200);
  const after = await p.evaluate(() => { const L = ARCH_LEVELS.music; return { rnd: L.rnd, errs: L.errs, scene: L.scene }; });
  ok(after.rnd === before.rnd, 'ошибка не сбросила раунд целиком (раунд ' + after.rnd + ')');
  ok(after.errs > 0, 'ошибка засчитана');
  ok(after.scene === 'listen', 'после ошибки фраза проигрывается заново');

  // 7. подсказка
  await p.evaluate(() => { ARCH_LEVELS.music.wait = 0; });
  await sleep(100);
  const barY = await p.evaluate(() => H - 12);
  await click(60, barY);
  await sleep(200);
  ok(await p.evaluate(() => G.screens.arlevel.hintT > 0), 'кнопка ПОДСКАЗКА показывает текст');

  // 8. выход из игры и сохранение
  for (let i = 0; i < 6 && await p.evaluate(() => G.state) !== 'desktop'; i++) {
    await p.keyboard.press('Escape');
    await sleep(350);
  }
  ok(await p.evaluate(() => G.state === 'desktop'), 'Escape вернул на рабочий стол (состояние: ' + await p.evaluate(() => G.state) + ')');
  const save = await p.evaluate(() => JSON.parse(localStorage.getItem('printILY3') || 'null'));
  ok(save && save.h && hearts0 && save.h.length === hearts0.length && save.h.every((v, i) => v === hearts0[i]),
     'основной счётчик сердец не тронут (' + (save ? save.h.length : '—') + ' в структуре)');
  ok(save && save.v === 2, 'сохранение версии 2');
  ok(save && save.a && save.a.t[2] >= 1, 'в архиве сохранены попытки: ' + (save && save.a ? JSON.stringify(save.a.t) : ''));


  // 9. две игры подряд доступны из архива
  await sleep(400);
  const again = await p.evaluate(() => !!(G.win && G.win.kind === 'arch'));
  ok(again, 'после выхода архив открылся снова');

  // 10. все пять игр зарегистрированы и открываются
  for (let i = 0; i < 5; i++) {
    const r = await p.evaluate((idx) => {
      const meta = ARCH_META[idx], lv = ARCH_LEVELS[meta.id];
      if (!lv) return { ok: false, why: 'нет уровня ' + meta.id };
      if (typeof lv.enter !== 'function') return { ok: false, why: 'нет enter у ' + meta.id };
      if (!lv.outro || lv.outro.length < 1) return { ok: false, why: 'нет аутро у ' + meta.id };
      const h = arHints(meta.id);
      if (h.length !== 3) return { ok: false, why: 'подсказок ' + h.length + ' у ' + meta.id };
      return { ok: true, name: meta.name, sub: meta.sub };
    }, i);
    ok(r.ok, 'игра ' + (i + 1) + ' «' + (r.name || '?') + '» готова' + (r.why ? ' — ' + r.why : ''));
  }

  ok(errs.length === 0, 'ошибок страницы нет' + (errs.length ? ': ' + errs.slice(0, 3).join(' | ') : ''));
  await b.close();
  console.log(fail ? '\n❌ провалено: ' + fail : '\n✅ АРХИВ: СКВОЗНОЙ ПРОГОН ПРОЙДЕН');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
