// Сквозной прогон НОВЫХ текстов: архив, терминал, MARIA.txt, экраны победы/провала.
const puppeteer = require('puppeteer');
const URL = 'http://127.0.0.1:8711/index.html';
let fails = 0, checks = 0;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
function ok(cond, msg){ checks++; if(cond) console.log('  ✓ ' + msg); else { fails++; console.log('  ✗ ' + msg); } }
function log(s){ console.log(s); }

(async () => {
  const b = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox', '--mute-audio'] });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(String(e)));
  p.on('console', m => { const t = m.text(); if (m.type() === 'error' && !/Failed to load resource/.test(t)) errs.push(t); });
  await p.setViewport({ width: 420, height: 760, deviceScaleFactor: 1 });
  await p.goto(URL, { waitUntil: 'load' });
  const ev = (js) => p.evaluate(js);
  const st = () => ev('G.state');
  // клики в координатах канваса
  await sleep(400);
  const SC = await ev('(()=>{const r=cv.getBoundingClientRect();return {x:r.width/W,y:r.height/H,l:r.left,t:r.top};})()');
  const click = async (x, y) => {
    await p.mouse.click(SC.l + x*SC.x, SC.t + y*SC.y);
    await sleep(220);
  };

  log('— подготовка: чистый архив и рабочий стол —');
  await ev('localStorage.clear(); AR.unpack(null); AR.done=[false,false,false,false,false]; AR.tries=[0,0,0,0,0]; AR.errors=[0,0,0,0,0]; AR.hints=[0,0,0,0,0]; AR.best=[0,0,0,0,0]; goNow("desktop")');
  await sleep(500);
  ok(await ev('!!G.screens.desktop.icons.find(i=>i.kind==="arch")'), 'иконка АРХИВ.exe на месте');
  ok(!(await ev('!!G.screens.desktop.icons.find(i=>i.kind==="maria")')), 'MARIA.txt пока нет (архив не пройден)');

  log('— вступление в архив —');
  const ib = await ev('G.screens.desktop.icons.find(i=>i.kind==="arch")');
  await click(ib.tx, ib.ty);
  await sleep(300);
  ok(await ev('G.win && G.win.kind==="arch" && G.win.data.page===0'), 'окно архива открылось на вступлении');
  ok((await ev('G.screens.desktop.startItems().map(i=>i.t).join("|")')).indexOf('HEART ARCHIVE') >= 0, 'пункт HEART ARCHIVE в меню «Пуск»');
  await p.keyboard.press('Space'); await sleep(300);
  ok(await ev('G.win.data.page===1'), 'ОТКРЫТЬ АРХИВ → список файлов');
  ok(await ev('(G.win.data.rows||[]).length===5'), 'в списке 5 игр');
  await p.keyboard.press('Escape'); await sleep(250);

  log('— экран «НЕ ПОЛУЧИЛОСЬ» —');
  await ev('G_arIdx=0; AR.tries[0]=3; G_ar.lose="Ничего страшного. Я рядом."; goNow("arlose"); G.screens.arlose.t=1.0');
  await sleep(400);
  ok(await ev('G.state==="arlose"'), 'открылся экран неудачи');
  const lbs = await ev('G.screens.arlose.btns.map(b=>G.screens.arlose.btns.indexOf(b)) && window.__b ? 0 : 0');
  const btnCount = await ev('(G.screens.arlose.btns||[]).length');
  ok(btnCount >= 3, 'кнопок на экране неудачи: ' + btnCount + ' (включая ПРОПУСТИТЬ)');
  // первая кнопка = попробовать ещё раз
  const b1 = await ev('(()=>{const b=G.screens.arlose.btns[0];return {x:b.x+b.w/2,y:b.y+b.h/2};})()');
  await click(b1.x, b1.y);
  await sleep(400);
  ok(await ev('G.state==="arlevel"'), 'ПОПРОБОВАТЬ ЕЩЁ вернуло в игру');
  const b2 = await ev('(()=>{G_arIdx=0; G_ar.lose="Ничего страшного."; goNow("arlose"); G.screens.arlose.t=1.0; return 0;})()');
  await sleep(300);
  const hintBtn = await ev('(()=>{const b=G.screens.arlose.btns[1];return {x:b.x+b.w/2,y:b.y+b.h/2};})()');
  await click(hintBtn.x, hintBtn.y);
  await sleep(400);
  ok(await ev('G.state==="arlevel" && G.screens.arlevel.hintNo===1'), 'ПОДСКАЗКА вернула в игру и показала подсказку 01');
  ok((await ev('G.screens.arlevel.hintText||""')).length > 10, 'текст подсказки есть');

  log('— подсказка в игре —');
  await ev('G.screens.arlevel.hintT=6.5');
  await sleep(200);
  ok(true, 'подсказка показывается поверх игры');

  log('— победа и outro —');
  await ev('G_arIdx=2; AR.done=[true,true,true,true,true]; AR.hints=[0,0,0,0,0]; AR.errors=[0,0,0,0,0]; arSaveNow(); arWin()');
  await sleep(500);
  ok(await ev('G.state==="arcomplete"'), 'после 5/5 открылся экран ARCHIVE COMPLETE');
  await sleep(2200);
  await p.keyboard.press('Space'); await sleep(600);
  ok(await ev('G.state==="desktop"'), 'НА РАБОЧИЙ СТОЛ вернул на рабочий стол');
  await sleep(900);
  ok(await ev('!!G.screens.desktop.icons.find(i=>i.kind==="maria")'), 'на рабочем столе появился MARIA.txt');
  const mi = await ev('G.screens.desktop.icons.find(i=>i.kind==="maria")');
  await click(mi.tx, mi.ty);
  await sleep(1400);
  ok(await ev('G.win && G.win.kind==="maria"'), 'MARIA.txt открылся');
  const mariaTxt = await ev('G.win ? "да" : "нет"');
  ok(mariaTxt === 'да', 'личный экран открыт');
  await p.keyboard.press('Escape'); await sleep(300);

  log('— повторный вход в архив —');
  const ib2 = await ev('G.screens.desktop.icons.find(i=>i.kind==="arch")');
  await click(ib2.tx, ib2.ty);
  await sleep(400);
  ok(await ev('G.win && G.win.data.page===0'), 'после полного архива снова вступление');
  await p.keyboard.press('Space'); await sleep(300);
  ok(await ev('G.win.data.page===1'), 'кнопка ОСТАТЬСЯ открыла список');
  await sleep(350);
  const st2 = await ev('(G.win.data.rows||[]).length===5 && (G.win.data.rows||[]).every(function(r){return AR.done[r.i];})');
  ok(st2 === true, 'все пять файлов помечены пройденными');
  await p.keyboard.press('Escape'); await sleep(250);

  log('— командная строка —');
  await ev('openTerm()'); await sleep(400);
  const type = async (cmd) => {
    for (const c of cmd) {
      if (c === ' ') { await p.keyboard.press('Space'); }
      else await p.keyboard.press('Key' + c.toUpperCase());
      await sleep(35);
    }
    await p.keyboard.press('Enter'); await sleep(250);
    return ev('G.win ? G.win.data.lines.map(l=>l.t).join(" ").replace(/\\s+/g," ") : ""');
  };
  let out = await type('help');
  ok(out.indexOf('archive — открыть архив') >= 0, 'help: есть archive');
  ok(out.indexOf('maria') >= 0, 'help: пасхалки перечислены');
  out = await type('hearts');
  ok(out.indexOf('АРХИВ: 5 / 5') >= 0, 'hearts: АРХИВ 5 / 5');
  ok(out.indexOf('ВСЕ ФРАГМЕНТЫ НАЙДЕНЫ.') >= 0, 'hearts: ВСЕ ФРАГМЕНТЫ НАЙДЕНЫ.');
  out = await type('about');
  ok(out.indexOf('5 архивных игр.') >= 0, 'about: пять архивных игр');
  out = await type('memory');
  ok(out.indexOf('MEMORY DATABASE') >= 0, 'пасхалка memory');
  out = await type('color pink');
  ok(out.indexOf('ЦВЕТ ИЗМЕНЁН') >= 0, 'color pink меняет цвет');
  out = await type('eternity');
  await sleep(2200);
  ok(out.indexOf('БЕСКОНЕЧНОСТЬ НЕ ПРЕДЕЛ') >= 0 || (await ev('G.win?G.win.data.lines.map(l=>l.t).join(" "):""')).indexOf('БЕСКОНЕЧНОСТЬ НЕ ПРЕДЕЛ') >= 0, 'пасхалка eternity');
  out = await type('smile');
  ok(out.indexOf('ПОИСК УЛЫБКИ') >= 0, 'пасхалка smile');
  out = await type('heart');
  ok(out.indexOf('HEARTOS HEART STATUS') >= 0, 'пасхалка heart');
  out = await type('zzz');
  ok(out.indexOf('КОМАНДА НЕ НАЙДЕНА.') >= 0, 'неизвестная команда');
  await p.keyboard.press('Escape'); await sleep(300);

  log('— запуск архива из терминала —');
  await ev('openTerm()'); await sleep(350);
  for (const c of 'archive') { await p.keyboard.press('Key' + c.toUpperCase()); await sleep(35); }
  await p.keyboard.press('Enter');
  await sleep(2500);
  ok(await ev('G.win && G.win.kind==="arch"'), 'команда archive открыла архив');

  log('— ошибки страницы —');
  ok(errs.length === 0, 'ошибок страницы нет' + (errs.length ? ': ' + errs.slice(0,3).join(' | ') : ''));

  await b.close();
  console.log('\n' + (fails ? '❌ провалов: ' + fails : '✅ НОВЫЕ ТЕКСТЫ: СКВОЗНОЙ ПРОГОН ПРОЙДЕН') + '  (проверок: ' + checks + ')');
  process.exit(fails ? 1 : 0);
})().catch(e => { console.error('ОШИБКА СКРИПТА:', e); process.exit(1); });
