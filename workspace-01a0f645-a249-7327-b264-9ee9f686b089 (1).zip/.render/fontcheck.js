const f = require('/home/user/game/src/font.json');
const ch = Object.keys(f);
const want = ['"', '«', '»', '—', '…', '!', '?', '♥', '№', 'ё', 'Ё', 'ъ', 'ь'];
for (const c of want) console.log(JSON.stringify(c), ch.indexOf(c) >= 0);
