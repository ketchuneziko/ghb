// Что именно рисуется в кадре: перехватываем text(), fillRect, drawImage
const puppeteer = require('puppeteer');

const SCENES = {
  boot:  { setup: `goNow('boot');`, t: 1.0 },
  lock:  { setup: `goNow('title');`, t: 1.0 },
  desk:  { setup: `goNow('desktop');`, t: 2.0 },
  deskWin: { setup: `G.hearts=[true,true,true,false,false,false,false,false]; goNow('desktop'); Win.open('map','ПРОГРЕСС.exe',{w:Math.min(W-8,224),h:Math.min(H-26,300)});`, t: 1.2 },
  start: { setup: `goNow('desktop'); G.screens.desktop.startOpen=true;`, t: 1.0 },
  dialog:{ setup: `G.level=0; startLevel(0);`, t: 1.0 },
  ruka:  { setup: `G.level=0; goNow('level'); LEVELS[0].enter();`, t: 2.2 },
  ritm:  { setup: `G.level=1; goNow('level'); LEVELS[1].enter();`, t: 3.0 },
  code:  { setup: `G.level=6; goNow('level'); LEVELS[6].enter();`, t: 0.6 },
  l1:    { setup: `G.level=2; goNow('level'); LEVELS[2].enter();`, t: 1.5 },
  l2:    { setup: `G.level=3; goNow('level'); LEVELS[3].enter();`, t: 1.5 },
  l3:    { setup: `G.level=4; goNow('level'); LEVELS[4].enter();`, t: 1.5 },
  l4:    { setup: `G.level=5; goNow('level'); LEVELS[5].enter();`, t: 1.5 },
  l5:    { setup: `G.level=7; goNow('level'); LEVELS[7].enter();`, t: 1.5 },
};

(async () => {
  const name = process.argv[2] || 'ruka';
  const sizeArg = (process.argv.find(a => a.startsWith('--size=')) || '--size=phone').slice(7);
  const SIZES = { phone: [420, 760], tall: [380, 900], wide: [900, 620] };
  const [VW, VH] = SIZES[sizeArg];
  const b = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=swiftshader', '--mute-audio'] });
  const p = await b.newPage();
  p.on('pageerror', e => console.log('PAGEERROR:', e.message));
  p.on('console', m => { if (/error/i.test(m.text())) console.log('CONSOLE:', m.text()); });
  await p.setViewport({ width: VW, height: VH, deviceScaleFactor: 1 });
  await p.goto('http://127.0.0.1:8711/index.html', { waitUntil: 'load' });
  await p.waitForFunction('typeof W!=="undefined" && W>0');
  await new Promise(r => setTimeout(r, 300));

  const sc = SCENES[name];
  const res = await p.evaluate((setup, t) => {
    (0, eval)(setup);
    window.requestAnimationFrame = function(){ return 0; };
    const steps = Math.round(t * 60);
    for (let i = 0; i < steps; i++) {
      const s = G.screens[G.state];
      if (s && s.update) s.update(1 / 60);
    }
    // перехват
    const log = [];
    const oldText = window.text;
    window.text = function (t, x, y, o) {
      o = o || {};
      const sc2 = o.sc || 1;
      const w = textW(t, sc2);
      let dx = Math.round(x);
      if (o.align === 'center') dx = Math.round(x - w / 2);
      else if (o.align === 'right') dx = Math.round(x - w);
      log.push({ k: 'T', s: t, x: dx, y: Math.round(y) - 3 * sc2, w, h: LH(sc2), col: o.color || '' });
      return oldText.apply(null, arguments);
    };
    const of = ctx.fillRect.bind(ctx), oi = ctx.drawImage.bind(ctx), os = ctx.strokeRect.bind(ctx);
    ctx.fillRect = function (x, y, w, h) { log.push({ k: 'R', x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h), col: ctx.fillStyle }); return of(x, y, w, h); };
    ctx.drawImage = function (img) { const a = arguments; if (a.length >= 5) log.push({ k: 'I', x: Math.round(a[1]), y: Math.round(a[2]), w: Math.round(a[3]), h: Math.round(a[4]) }); return oi.apply(ctx, a); };
    ctx.strokeRect = function (x, y, w, h) { log.push({ k: 'S', x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) }); return os(x, y, w, h); };
    let err = null;
    try { const s = G.screens[G.state]; if (s && s.draw) s.draw(); } catch (e) { err = e.message; }
    window.text = oldText; ctx.fillRect = of; ctx.drawImage = oi; ctx.strokeRect = os;
    return { state: G.state, W, H, err, log };
  }, sc.setup, sc.t);

  console.log(`=== ${name} (${sizeArg})  state=${res.state}  W=${res.W} H=${res.H}  ops=${res.log.length}  err=${res.err || 'нет'} ===`);
  // текст — целиком
  for (const o of res.log.filter(o => o.k === 'T')) {
    const oob = (o.x < 0 || o.y < 0 || o.x + o.w > res.W || o.y + o.h > res.H) ? '  <<< ВЫХОДИТ ЗА ЭКРАН' : '';
    console.log(`TXT  "${o.s}"  x=${o.x}..${o.x + o.w}  y=${o.y}..${o.y + o.h}  цвет=${o.col}${oob}`);
  }
  // крупные прямоугольники
  const big = res.log.filter(o => o.k === 'R' && o.w * o.h > 400 && !(o.w > res.W - 2 && o.h > res.H - 2))
    .sort((a, b) => b.w * b.h - a.w * a.h).slice(0, 16);
  console.log('--- крупные заливки ---');
  for (const o of big) console.log(`RECT ${o.w}x${o.h} at (${o.x},${o.y}) ${o.col}`);
  // статистика
  const cnt = {};
  for (const o of res.log) cnt[o.k] = (cnt[o.k] || 0) + 1;
  console.log('--- всего операций:', JSON.stringify(cnt));
  // картинки
  const imgs = res.log.filter(o => o.k === 'I');
  if (imgs.length) {
    console.log('--- картинки ---');
    for (const o of imgs.slice(0, 20)) console.log(`IMG ${o.w}x${o.h} at (${o.x},${o.y})`);
  }
  await b.close();
})().catch(e => { console.error('FAIL', e.stack); process.exit(1); });
