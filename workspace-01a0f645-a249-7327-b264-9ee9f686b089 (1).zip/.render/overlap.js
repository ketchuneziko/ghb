// Что именно рисуется в кадре: перехватываем text(), fillRect, drawImage
const puppeteer = require('puppeteer');

const LV = (i) => `G.level=${i}; goNow('level'); LEVELS[${i}].enter();`;
const HEART_FULL = `G.hearts=[true,true,true,true,true,true,true,true,true,true,true,true,true];`;
const MAPWIN = `Win.open('map','\u041f\u0420\u041e\u0413\u0420\u0415\u0421\u0421.exe',{w:Math.min(W-8,224),h:Math.min(H-26,300)});`;
const SCENES = {
  boot1:  { setup: `goNow('boot');`, t: 1.1 },
  boot2:  { setup: `goNow('boot');`, t: 4.0 },
  desk1:  { setup: `goNow('desktop');`, t: 0.25 },
  desk:   { setup: `goNow('desktop');`, t: 2.0 },
  deskWin:{ setup: HEART_FULL + ` goNow('desktop'); G.sel=1;` + MAPWIN, t: 1.2 },
  deskBonus:{ setup: HEART_FULL + ` goNow('desktop'); G.sel=6;` + MAPWIN + ` G.win.tab=1;`, t: 1.2 },
  deskFinal:{ setup: HEART_FULL + ` goNow('desktop'); G.sel=13;` + MAPWIN, t: 1.2 },
  start:  { setup: `goNow('desktop'); G.screens.desktop.startOpen=true;`, t: 1.0 },
  syswin: { setup: `goNow('desktop'); openSys('\u041a\u041e\u0420\u0417\u0418\u041d\u0410',['\u0421\u0435\u0440\u0434\u0446\u0430 \u0443\u0434\u0430\u043b\u044f\u0442\u044c \u043d\u0435\u043b\u044c\u0437\u044f.','\u042f \u043f\u0440\u043e\u0432\u0435\u0440\u044f\u043b.']);`, t: 0.6 },
  readme: { setup: `goNow('desktop'); Win.open('readme','README.txt',{w:Math.min(W-20,200),h:104});`, t: 0.8 },
  devlogF:{ setup: `goNow('desktop'); openTxtFile('DEV_LOG_FINAL.txt');`, t: 0.5 },
  lastfile:{ setup: `goNow('desktop'); G.hearts=G.hearts.map(()=>true); AR.done=[true,true,true,true,true]; ensureExtraIcons(); openTxtFile('README_FINAL.txt');`, t: 0.5 },
  setwin: { setup: `goNow('desktop'); Win.open('set','\u041f\u0410\u0420\u0410\u041c\u0415\u0422\u0420\u042b  v1.0',{w:Math.min(W-14,214),h:112});`, t: 0.4 },
  dialog: { setup: `G.level=0; startLevel(0);`, t: 1.2 },
  dialog2:{ setup: `G.level=0; startLevel(0); G.fails[0]=3; G.dialog.canSkip=true;`, t: 1.2 },
  load:   { setup: `goNow('desktop'); G.pending={type:'level',idx:0,t:0.3}; Win.open('load','\u0417\u0410\u041f\u0423\u0421\u041a \u0428\u0418\u0424\u0420.exe',{w:170,h:56});`, t: 0.4 },
  ep1:    { setup: LV(0) + `LEVELS[0].sh=1;`, t: 1.0 },
  ep1b:   { setup: LV(0) + `LEVELS[0].sh=13;`, t: 1.0 },
  ep2:    { setup: LV(1) + `var L=LEVELS[1];L.beat=3;L.beatT=0.5;L.hit=4;L.combo=4;`, t: 0.6 },
  ep2b:   { setup: LV(1) + `var L=LEVELS[1];L.beat=2;L.beatT=0.3;L.hit=6;L.miss=1;L.msg='\u041f\u041e\u0417\u0414\u041d\u041e';L.msgT=.4;`, t: 0.6 },
  ep3:    { setup: LV(2) + `var L=LEVELS[2];L.stop=1;L.seen=[true,false,false];L.left=18;`, t: 1.0 },
  ep4:    { setup: LV(3) + `var L=LEVELS[3];L.cx=4;L.cy=3;L.steps=17;`, t: 1.0 },
  ep5:    { setup: LV(4) + `var L=LEVELS[4];L.done=[true,false,false];L.step=1;L.pick=0;L.err=1;L.msg=2;`, t: 0.8 },
  ruka:   { setup: LV(5), t: 2.2 },
  arythm: { setup: LV(6), t: 3.0 },
  serdca: { setup: LV(7), t: 3.0 },
  amaze:  { setup: LV(8), t: 1.5 },
  azont:  { setup: LV(9), t: 3.0 },
  amemori:{ setup: LV(10), t: 1.0 },
  acode:  { setup: LV(11), t: 0.6 },
  aprint: { setup: LV(12), t: 1.0 },
  reward: { setup: HEART_FULL + ` G.level=3; winLevel(3);`, t: 0.9 },
  term:   { setup: `goNow('desktop'); openTerm(); G.win.data.cmd='he'; G.win.data.t=0.3;`, t: 0.6 },
  term2:  { setup: `goNow('desktop'); openTerm(); G.win.data.lines=[{t:'\u0412\u044b\u043f\u043e\u043b\u043d\u0435\u043d\u0438\u0435 \u043a\u043e\u043c\u0430\u043d\u0434\u044b love...',c:'#ff5d8f'},{t:'\u041f\u0440\u0435\u0434\u0443\u043f\u0440\u0435\u0436\u0434\u0435\u043d\u0438\u0435: \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u043d\u0435\u0436\u043d\u043e\u0441\u0442\u0438 \u0437\u0430\u0448\u043a\u0430\u043b\u0438\u0432\u0430\u0435\u0442!',c:'#a08cc0'},{t:'',c:''}]; G.win.data.cmd='lov'; G.win.data.t=0.3; loveMagic(6); spawnLove(50);`, t: 0.5 },
  arch:    { setup: `goNow('desktop'); openArchiveWin();`, t: 0.5 },
  maria:   { setup: `goNow('desktop'); AR.done=[true,true,true,true,true]; G.screens.desktop.buildIcons(); G.screens.desktop.layout(); G.screens.desktop.launch(G.screens.desktop.icons.find(function(i){return i.kind==='maria';}), true);`, t: 1.2 },
  start2:  { setup: `goNow('desktop'); G.screens.desktop.startOpen=true;`, t: 0.5 },
  setwin2: { setup: `goNow('desktop'); openSettings();`, t: 0.5 },
  archAll: { setup: `goNow('desktop'); AR.done=[true,true,true,false,true]; AR.hints=[0,1,0,0,0]; AR.errors=[0,2,0,0,0]; AR.tries=[1,2,1,1,1]; AR.best=[12000,31000,0,0,21000]; openArchiveWin(); G.win.data.page=1;`, t: 0.5 },
  archSt:  { setup: `goNow('desktop'); AR.done=[true,true,false,true,false]; AR.hints=[0,1,0,2,0]; AR.errors=[0,3,0,5,0]; AR.tries=[0,1,0,2,0]; openArchiveWin(); G.win.data.page=1; G.win.data.tab=1;`, t: 0.5 },
  archDone:{ setup: `goNow('desktop'); AR.done=[true,true,true,true,true]; openArchiveWin();`, t: 0.5 },
  arcardR: { setup: `goNow('desktop'); AR.done=[true,true,false,false,false]; AR.hints=[0,1,0,0,0]; AR.errors=[0,2,0,0,0]; AR.tries=[1,2,0,0,0]; G_arIdx=0; startArch(0); G.screens.arcard.t=9;`, t: 0.2 },
  arrw:    { setup: `goNow('desktop'); AR.done=[false,true,false,false,false]; AR.tries=[1,2,0,0,0]; AR.errors=[0,3,0,0,0]; AR.best=[0,31400,0,0,0]; G_arIdx=1; goNow('arreward'); G.screens.arreward.t=2.4;`, t: 0.2 },
  arlose:  { setup: `goNow('desktop'); AR.tries=[1,3,0,0,0]; G_arIdx=1; G_ar.lose='\u0422\u0430\u0439\u043d\u0438\u043a \u043d\u0435 \u0432 \u0442\u043e\u0439 \u0441\u0442\u0435\u043d\u0435. \u0422\u044b \u0431\u044b\u043b\u0430 \u043f\u0440\u0430\u0432\u0430 \u0440\u0430\u043d\u044c\u0448\u0435.'; goNow('arlose'); G.screens.arlose.t=1.2;`, t: 0.2 },
  arcompl: { setup: `goNow('desktop'); AR.done=[true,true,true,true,true]; goNow('arcomplete'); G.screens.arcomplete.t=3.4;`, t: 0.2 },
  arcard:  { setup: `G_arIdx=0; startArch(0); G.screens.arcard.t=9;`, t: 0.5 },
  arc1:    { setup: `G_arIdx=0; startArch(0); var L=ARCH_LEVELS.cipher; G.screens.arlevel.card=0; L.enter(); L.setScene('l1'); L.sel1=1; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc1b:   { setup: `G_arIdx=0; startArch(0); var L=ARCH_LEVELS.cipher; G.screens.arlevel.card=0; L.enter(); L.setScene('l2'); L.tapRow(1); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc1c:   { setup: `G_arIdx=0; startArch(0); var L=ARCH_LEVELS.cipher; G.screens.arlevel.card=0; L.enter(); L.setScene('l2'); L.tapRow(1); L.setScene('l3'); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc1d:   { setup: `G_arIdx=0; startArch(0); var L=ARCH_LEVELS.cipher; G.screens.arlevel.card=0; L.enter(); L.setScene('win'); for(var i=0;i<150;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc2:    { setup: `G_arIdx=1; startArch(1); var L=ARCH_LEVELS.stars; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc2b:   { setup: `G_arIdx=1; startArch(1); var L=ARCH_LEVELS.stars; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var k=0;k<5;k++){var li=L.stars(); for(var i=0;i<li.length;i++) if(li[i].real && li[i].n===k){L.pick(i);break;}} for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc2c:   { setup: `G_arIdx=1; startArch(1); var L=ARCH_LEVELS.stars; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.zoom=1.5; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc2d:   { setup: `G_arIdx=1; startArch(1); var L=ARCH_LEVELS.stars; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var k=0;k<10;k++){var li=L.stars(); for(var i=0;i<li.length;i++) if(li[i].real && li[i].n===k){L.pick(i);break;}} for(var i=0;i<200;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc3:    { setup: `G_arIdx=2; startArch(2); var L=ARCH_LEVELS.music; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.si=2; L.si=0; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc3b:   { setup: `G_arIdx=2; startArch(2); var L=ARCH_LEVELS.music; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.startRound(2); L.si=3; L.si=0; L.setScene('repeat'); L.pi=2; L.hit=[0,1,0,0,0,0,0]; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc3c:   { setup: `G_arIdx=2; startArch(2); var L=ARCH_LEVELS.music; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.startRound(5); L.si=2; L.si=0; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc3d:   { setup: `G_arIdx=2; startArch(2); var L=ARCH_LEVELS.music; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.startRound(6); L.setScene('win'); L.okT=2.0; for(var i=0;i<60;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc4:    { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.openDossier(0); L.win.anim=1; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc4b:   { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<3;i++)L.openDossier(i); L.win=null; L.qIdx=3; L.qT=3; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc4c:   { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<5;i++)L.openDossier(i); L.win=null; L.sawAns=true; L.setScene('verdict'); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc4d:   { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<5;i++)L.openDossier(i); L.win=null; L.sawAns=true; L.setScene('quiz'); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc4e:   { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.setScene('win'); L.okT=1.4; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc5:    { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc5b:   { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); var o=L.want(); L.touch(o[0]); L.touch(o[1]); L.touch(o[3]); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc5c:   { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); var o=L.want(); for(var k=0;k<7;k++)L.touch(o[k]); L.startCycle(2); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.2 },
  arc5d:   { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); for(var c=0;c<3;c++){L.startCycle(c); var o=L.want(); for(var k=0;k<7;k++)L.touch(o[k]);} for(var i=0;i<120;i++)L.sceneT+=1/60;`, t: 0.2 },
  finFly: { setup: `goNow('finale');`, t: 1.6 },
  finFly2:{ setup: `goNow('finale');`, t: 3.0 },
  finBeat:{ setup: `goNow('finale');`, t: 6.2 },
  finText:{ setup: `goNow('finale'); var s=G.screens.finale; s.phase='text'; s.t=2; s.chars=1e9; s.btn=0;`, t: 0.3 },
  finAsk1:{ setup: `goNow('finale'); var s=G.screens.finale; s.t=99; s.chars=1e9; s.phase='ask1'; s.t=1.2; s.btn=1;`, t: 0.4 },
  finAsk2:{ setup: `goNow('finale'); var s=G.screens.finale; s.phase='ask2'; s.t=1.2; s.btn=2;`, t: 0.4 },
  finScroll:{ setup: `goNow('finale'); var s=G.screens.finale; s.phase='text'; s.t=2; s.chars=1e9; s.btn=0; s.scroll=3; s.maxScroll=5;`, t: 0.3 },
  finEnd: { setup: `goNow('finale'); var s=G.screens.finale; s.phase='end'; s.t=1.4; s.btn=-1;`, t: 0.6 },
  mrest:  { setup: `MR.room=true; goNow('restored'); var s=G.screens.restored; for(var i=0;i<200;i++)s.t+=1/60; s.shown=true;`, t: 0.2 },
  mroom:  { setup: `MR.room=true; MR.seen=[0,0,0]; goNow('memroom'); var s=G.screens.memroom; for(var i=0;i<40;i++)s.t+=1/60;`, t: 0.2 },
  mroom2: { setup: `MR.room=true; MR.seen=[1,1,1]; goNow('memroom'); var s=G.screens.memroom; for(var i=0;i<80;i++)s.t+=1/60;`, t: 0.2 },
  mroomz: { setup: `MR.room=true; MR.seen=[0,0,0]; goNow('memroom'); var s=G.screens.memroom; for(var i=0;i<40;i++)s.t+=1/60; s.openPhoto(2); s.tOpen=3.2;`, t: 0.2 }
};
(async () => {
  const args = process.argv.slice(2).filter(a=>!a.startsWith('--'));
  const names = args.length ? args : Object.keys(SCENES);
  const sizeArg = (process.argv.find(a => a.startsWith('--size=')) || '--size=phone').slice(7);
  const SIZES = { phone: [420, 760], tall: [380, 900], wide: [900, 620] };
  const [VW, VH] = SIZES[sizeArg];
  const b = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=swiftshader', '--mute-audio'] });
  const p = await b.newPage();
  p.on('pageerror', e => console.log('PAGEERROR:', e.message));
  p.on('console', m => { if (/error/i.test(m.text())) console.log('CONSOLE:', m.text()); });
  await p.setViewport({ width: VW, height: VH, deviceScaleFactor: 1 });
  await p.goto('http://127.0.0.1:8711/index.html', { waitUntil: 'load' });
  await p.waitForFunction('typeof W!=="undefined" && W>0');
  await new Promise(r => setTimeout(r, 300));

  let bad = 0;
  for (const name of names) {
  const sc = SCENES[name];
  if (!sc) { console.log('нет сцены ' + name); continue; }
  const res = await p.evaluate((setup, t) => {
    // сбросить эффекты прошлой сцены, иначе всплывающий текст «наезжает» на новую сцену
    try { POPS.length = 0; RINGS.length = 0; FX.length = 0; } catch (e) {}
    (0, eval)(setup);
    window.requestAnimationFrame = function(){ return 0; };
    const steps = Math.round(t * 60);
    for (let i = 0; i < steps; i++) {
      const s = G.screens[G.state];
      if (s && s.update) s.update(1 / 60);
    }
    // перехват
    const log = [];
    const oldText = window.text;
    window.text = function (t, x, y, o) {
      o = o || {};
      const sc2 = o.sc || 1;
      const w = textW(t, sc2);
      let dx = Math.round(x);
      if (o.align === 'center') dx = Math.round(x - w / 2);
      else if (o.align === 'right') dx = Math.round(x - w);
      log.push({ k: 'T', s: t, x: dx, y: Math.round(y) - 3 * sc2, w, h: LH(sc2), col: o.color || '' });
      return oldText.apply(null, arguments);
    };
    const of = ctx.fillRect.bind(ctx), oi = ctx.drawImage.bind(ctx), os = ctx.strokeRect.bind(ctx);
    ctx.fillRect = function (x, y, w, h) { log.push({ k: 'R', x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h), col: ctx.fillStyle }); return of(x, y, w, h); };
    ctx.drawImage = function (img) { const a = arguments; if (a.length >= 5) log.push({ k: 'I', x: Math.round(a[1]), y: Math.round(a[2]), w: Math.round(a[3]), h: Math.round(a[4]) }); return oi.apply(ctx, a); };
    ctx.strokeRect = function (x, y, w, h) { log.push({ k: 'S', x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(h) }); return os(x, y, w, h); };
    let err = null;
    try { const s = G.screens[G.state]; if (s && s.draw) s.draw(); } catch (e) { err = e.message; }
    window.text = oldText; ctx.fillRect = of; ctx.drawImage = oi; ctx.strokeRect = os;
    return { state: G.state, W, H, err, log };
  }, sc.setup, sc.t);


  // индекс каждой операции — чтобы понимать, что нарисовано поверх
  res.log.forEach((o, i) => { o.i = i; });
  const T = res.log.filter(o => o.k === 'T' && o.s && o.s.trim());
  const R = res.log.filter(o => o.k === 'R');
  // текст, который потом полностью накрыли заливкой (окно/меню поверх иконки) — не считаем
  const hidden = (a) => R.some(r => r.i > a.i && r.x <= a.x + 1 && r.y <= a.y + 1 &&
    r.x + r.w >= a.x + a.w - 1 && r.y + r.h >= a.y + a.h - 1 && r.w > 20 && r.h > 8);
  console.log(`=== ${name} (${sizeArg}) ${res.W}x${res.H} текстов=${T.length} err=${res.err||'нет'} ===`);
  // 1) наложения текста на текст
  const ov = [];
  for (let i = 0; i < T.length; i++) for (let j = i + 1; j < T.length; j++) {
    const a = T[i], b = T[j];
    const ix = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
    const iy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
    if (hidden(a) || hidden(b)) continue;
    // тень под текстом рисуется второй раз в той же точке — это не наложение
    if (a.s === b.s && a.x === b.x && a.y === b.y && a.w === b.w && a.h === b.h) continue;
    if (ix > 2 && iy > 2) {
      const area = ix * iy, small = Math.min(a.w * a.h, b.w * b.h);
      ov.push({ a: a.s, b: b.s, pct: Math.round(area / small * 100), ix, iy,
                ax: a.x, ay: a.y, bx: b.x, by: b.y });
    }
  }
  ov.sort((p, q) => q.pct - p.pct);
  if (process.env.DUMP) T.forEach(o => console.log(`   T "${o.s}" x=${o.x}..${o.x + o.w} y=${o.y}..${o.y + o.h} sc=${o.w}`));
  if (!ov.length) console.log('  наложений текста нет');
  for (const o of ov.slice(0, 12)) console.log(`  НАЛОЖ ${o.pct}%  "${o.a}" (${o.ax},${o.ay}) x "${o.b}" (${o.bx},${o.by})  ${o.ix}x${o.iy}px`);
  // 2) текст, налезающий на край экрана
  let oob = 0;
  for (const o of T) {
    if (hidden(o)) continue;
    if (o.x < 0 || o.y < 0 || o.x + o.w > res.W || o.y + o.h > res.H) {
      oob++;
      console.log(`  ЗА ЭКРАН "${o.s}" x=${o.x}..${o.x + o.w} y=${o.y}..${o.y + o.h} (экран ${res.W}x${res.H})`);
    }
  }

  if (ov.length || oob.length) bad++;
  }
  console.log(bad ? `ВНИМАНИЕ: сцен с наложениями — ${bad}` : 'ОНАЛОЖЕНИЙ НЕТ НИ В ОДНОЙ СЦЕНЕ');
  await b.close();
})().catch(e => { console.error('FAIL', e.stack); process.exit(1); });
