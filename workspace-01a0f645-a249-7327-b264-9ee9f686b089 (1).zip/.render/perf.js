// Замер: сколько миллисекунд занимает кадр на каждом экране
const puppeteer = require('puppeteer');
const SCENES = {
  boot:`goNow('boot')`, lock:`goNow('title')`, desk:`goNow('desktop')`,
  ep1:`G.level=0;goNow('level');LEVELS[0].enter()`,
  ep2:`G.level=1;goNow('level');LEVELS[1].enter()`,
  ep3:`G.level=2;goNow('level');LEVELS[2].enter()`,
  ep4:`G.level=3;goNow('level');LEVELS[3].enter()`,
  ep5:`G.level=4;goNow('level');LEVELS[4].enter()`,
  ruka:`G.level=5;goNow('level');LEVELS[5].enter()`,
  ritm:`G.level=6;goNow('level');LEVELS[6].enter()`,
  serdca:`G.level=7;goNow('level');LEVELS[7].enter()`,
  maze:`G.level=8;goNow('level');LEVELS[8].enter()`,
  zont:`G.level=9;goNow('level');LEVELS[9].enter()`,
  memori:`G.level=10;goNow('level');LEVELS[10].enter()`,
  code:`G.level=11;goNow('level');LEVELS[11].enter()`,
  print:`G.level=12;goNow('level');LEVELS[12].enter()`,
  finFly:`goNow('finale')`, finBeat:`G.screens.finale.phase='beat'`, finText:`G.screens.finale.phase='text'`, finAsk:`G.screens.finale.phase='ask1'`,
  term:`goNow('desktop');openTerm()`,
  arcard:`G_arIdx=0;startArch(0)`,
  arc1:`G_arIdx=0;startArch(0);G.screens.arlevel.card=0;ARCH_LEVELS.cipher.enter();goNow('arlevel')`,
  arc1c:`G_arIdx=0;startArch(0);G.screens.arlevel.card=0;ARCH_LEVELS.cipher.enter();goNow('arlevel');ARCH_LEVELS.cipher.setScene('l3')`,
  arc2:`G_arIdx=1;startArch(1);G.screens.arlevel.card=0;ARCH_LEVELS.stars.enter();goNow('arlevel')`,
  arc2d:`G_arIdx=1;startArch(1);G.screens.arlevel.card=0;ARCH_LEVELS.stars.enter();goNow('arlevel');ARCH_LEVELS.stars.setScene('win')`,
  arc3:`G_arIdx=2;startArch(2);G.screens.arlevel.card=0;ARCH_LEVELS.music.enter();goNow('arlevel')`,
  arc4:`G_arIdx=3;startArch(3);G.screens.arlevel.card=0;ARCH_LEVELS.case_.enter();goNow('arlevel')`,
  arc5:`G_arIdx=4;startArch(4);G.screens.arlevel.card=0;ARCH_LEVELS.room.enter();goNow('arlevel')`,
  archwin:`goNow('desktop');openArchiveWin()`,
  archlist:`goNow('desktop');AR.done=[true,true,true,false,true];AR.best=[12000,31000,0,0,21000];openArchiveWin();G.win.data.page=1`,
  archdone:`goNow('desktop');AR.done=[true,true,true,true,true];openArchiveWin()`,
  arcompl:`goNow('desktop');AR.done=[true,true,true,true,true];goNow('arcomplete');G.screens.arcomplete.t=3.4`,
  arrw:`goNow('desktop');AR.done=[false,true,false,false,false];G_arIdx=1;goNow('arreward');G.screens.arreward.t=2.4`,
  arlose:`goNow('desktop');AR.tries=[1,3,0,0,0];G_arIdx=1;G_ar.lose='Тайник не в той стене.';goNow('arlose');G.screens.arlose.t=1.2`,
  memroom:`MR.room=true;MR.seen=[1,1,1];goNow('memroom')`,
  memzoom:`MR.room=true;goNow('memroom');G.screens.memroom.openPhoto(2)`,
  restored:`MR.room=true;goNow('restored')`,
  maria:`goNow('desktop');AR.done=[true,true,true,true,true];G.screens.desktop.buildIcons();G.screens.desktop.layout();G.screens.desktop.launch(G.screens.desktop.icons.find(function(i){return i.kind==='maria';}),true)`,
};
(async () => {
  const sizeArg = (process.argv.find(a=>a.startsWith('--size='))||'--size=phone').slice(7);
  const SIZES={phone:[420,760],wide:[900,620]};
  const [VW,VH]=SIZES[sizeArg];
  const b = await puppeteer.launch({args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=swiftshader','--mute-audio']});
  const p = await b.newPage();
  p.on('pageerror', e=>console.log('PAGEERROR:', e.message));
  await p.setViewport({width:VW,height:VH});
  await p.goto('http://127.0.0.1:8711/index.html',{waitUntil:'load'});
  await p.waitForFunction('typeof W!=="undefined" && W>0');
  await new Promise(r=>setTimeout(r,400));
  for (const [n,s] of Object.entries(SCENES)) {
    const ms = await p.evaluate((setup)=>{
      (0,eval)(setup);
      const s2 = G.screens[G.state];
      for(let i=0;i<20;i++) if(s2.update) s2.update(1/60);
      const t0 = performance.now();
      for(let i=0;i<40;i++){ if(s2.update) s2.update(1/60); if(s2.draw) s2.draw(); }
      return (performance.now()-t0)/40;
    }, s);
    console.log(`${n.padEnd(8)} ${ms.toFixed(2)} мс/кадр  ${(1000/ms).toFixed(0)} fps`);
  }
  await b.close();
})();
