// Быстрая проверка метрик текста: node probe.js <выражение>
const puppeteer = require('puppeteer');
const path = require('path');
const EXPR = process.argv.slice(2).join(' ') || '1+1';
(async () => {
  const b = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const p = await b.newPage();
  await p.setViewport({ width: 420, height: 760, deviceScaleFactor: 1 });
  await p.goto('http://127.0.0.1:8711/index.html', { waitUntil: 'load' });
  await p.evaluate(() => goNow('desktop'));
  await new Promise(r => setTimeout(r, 300));
  const out = await p.evaluate(EXPR);
  console.log(JSON.stringify(out, null, 1));
  await b.close();
})().catch(e => { console.error('ERR', e.message); process.exit(1); });
