// Рендер кадров игры в PNG через headless-браузер (canvas -> toDataURL)
const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');

const OUT = path.join(__dirname, 'shots');
fs.mkdirSync(OUT, { recursive: true });
const URL = 'http://127.0.0.1:8711/index.html';

const LV = (i) => `G.level=${i}; goNow('level'); LEVELS[${i}].enter();`;
const HEART_FULL = `G.hearts=[true,true,true,true,true,true,true,true,true,true,true,true,true];`;
const SCENES = {
  boot1:   { setup: `goNow('boot');`, t: 1.1 },
  boot2:   { setup: `goNow('boot');`, t: 4.0 },
  lock:    { setup: `goNow('title');`, t: 1.0 },
  desk1:   { setup: `goNow('desktop');`, t: 0.25 },
  desk:    { setup: `goNow('desktop');`, t: 2.0 },
  card:    { setup: `G.level=2; goNow('level'); G.cardT=1.75; LEVELS[2].enter();`, t: 0.55 },
  card2:   { setup: `G.level=5; goNow('level'); G.cardT=1.75; LEVELS[5].enter();`, t: 0.9 },
  deskWin: { setup: `G.hearts=[true,true,true,false,false,false,false,false,false,false,false,false,false]; goNow('desktop'); G.sel=1; Win.open('map','ПРОГРЕСС.exe',{w:Math.min(W-8,224),h:Math.min(H-26,300)});`, t: 1.2 },
  deskBonus:{ setup: `G.hearts=[true,true,true,false,false,false,false,false,false,false,false,false,false]; goNow('desktop'); G.sel=6; Win.open('map','ПРОГРЕСС.exe',{w:Math.min(W-8,224),h:Math.min(H-26,300)}); G.win.tab=1;`, t: 1.2 },
  deskFinal:{ setup: HEART_FULL + ` goNow('desktop'); G.sel=13; Win.open('map','ПРОГРЕСС.exe',{w:Math.min(W-8,224),h:Math.min(H-26,300)});`, t: 1.2 },
  start:   { setup: `goNow('desktop'); G.screens.desktop.startOpen=true;`, t: 1.0 },
  syswin:  { setup: `goNow('desktop'); openSys('КОРЗИНА',['Сердца удалять нельзя.','Я проверял.']);`, t: 0.6 },
  readme:  { setup: `goNow('desktop'); Win.open('readme','README.txt',{w:Math.min(W-20,200),h:104});`, t: 0.8 },
  devlist: { setup: `goNow('desktop'); openDevList(); G.win.data.sel=2;`, t: 0.6 },
  devlog1: { setup: `goNow('desktop'); openTxtFile('DEV_LOG_01.txt', null, 'devlist');`, t: 0.8 },
  devlogF: { setup: `goNow('desktop'); openTxtFile('DEV_LOG_FINAL.txt');`, t: 0.8 },
  lastfile2x:{ setup: `goNow('desktop'); G.hearts=G.hearts.map(()=>true); AR.done=[true,true,true,true,true]; ensureExtraIcons();`, t: 2.0 },
  lastfile:{ setup: `goNow('desktop'); G.hearts=G.hearts.map(()=>true); AR.done=[true,true,true,true,true]; ensureExtraIcons(); openTxtFile('README_FINAL.txt'); G.win.data.scroll=99;`, t: 0.8 },
  lastfile2:{ setup: `goNow('desktop'); G.hearts=G.hearts.map(()=>true); AR.done=[true,true,true,true,true]; ensureExtraIcons(); openTxtFile('README_FINAL.txt'); G.win.data.scroll=0;`, t: 0.8 },
  setwin:  { setup: `goNow('desktop'); Win.open('set','ПАРАМЕТРЫ  v1.0',{w:Math.min(W-14,214),h:112});`, t: 0.4 },
  arch:    { setup: `goNow('desktop'); openArchiveWin();`, t: 0.8 },
  termFore:{ setup: `goNow('desktop'); openTerm(); termExec(G.win,'forever'); for(var i=0;i<120;i++) termTick(1/60);`, t: 0.4 },
  termHelp:{ setup: `goNow('desktop'); openTerm(); termExec(G.win,'help'); for(var i=0;i<40;i++) termTick(1/60);`, t: 0.4 },
  maria:   { setup: `goNow('desktop'); AR.done=[true,true,true,true,true]; AR.tries=[1,1,1,1,1]; G.screens.desktop.buildIcons(); G.screens.desktop.layout(); G.screens.desktop.launch(G.screens.desktop.icons.find(function(i){return i.kind==='maria';}), true);`, t: 3.2 },
  mariaIc: { setup: `goNow('desktop'); AR.done=[true,true,true,true,true]; AR.tries=[1,1,1,1,1]; G.screens.desktop.buildIcons(); G.screens.desktop.layout(); G.screens.desktop.t=2.0;`, t: 2.0 },
  start2:  { setup: `goNow('desktop'); G.screens.desktop.startOpen=true;`, t: 1.0 },
  setwin2: { setup: `goNow('desktop'); openSettings();`, t: 0.6 },
  archSel: { setup: `goNow('desktop'); openArchiveWin(); G.win.data.page=1; G.win.data.sel=2;`, t: 0.8 },
  archAll: { setup: `goNow('desktop'); AR.done=[true,true,true,false,true]; AR.hints=[0,1,0,0,0]; AR.errors=[0,2,0,0,0]; AR.tries=[1,2,1,1,1]; AR.best=[12000,31000,0,0,21000]; openArchiveWin(); G.win.data.page=1; G.win.data.sel=1;`, t: 0.8 },
  archDone:{ setup: `goNow('desktop'); AR.done=[true,true,true,true,true]; AR.hints=[0,0,0,0,0]; AR.errors=[0,0,0,0,0]; AR.tries=[1,1,1,1,1]; AR.best=[12000,31000,9000,45000,21000]; openArchiveWin();`, t: 0.8 },
  archSt:  { setup: `goNow('desktop'); AR.done=[true,true,false,true,false,true]; AR.best=[1,2,0,3,0,4]; AR.tries=[0,1,0,2,0,1]; AR.hints=[0,1,0,2,0,0]; AR.errors=[0,3,0,5,0,2]; openArchiveWin(); G.win.data.page=1; G.win.data.tab=1;`, t: 0.8 },
  arcard:  { setup: `G_arIdx=0; goNow('arcard');`, t: 1.0 },
  arcardR: { setup: `goNow('desktop'); AR.done=[true,true,false,false,false]; AR.hints=[0,1,0,0,0]; AR.errors=[0,2,0,0,0]; AR.tries=[1,2,0,0,0]; G_arIdx=0; startArch(0); G.screens.arcard.t=9;`, t: 0.1 },
  arrw:    { setup: `goNow('desktop'); AR.done=[false,true,false,false,false]; AR.tries=[1,2,0,0,0]; AR.errors=[0,3,0,0,0]; AR.best=[0,31400,0,0,0]; G_arIdx=1; goNow('arreward'); G.screens.arreward.t=2.4;`, t: 0.1 },
  arlose:  { setup: `goNow('desktop'); AR.tries=[1,3,0,0,0]; G_arIdx=1; G_ar.lose='Тайник не в той стене. Ты была права раньше.'; goNow('arlose'); G.screens.arlose.t=1.2;`, t: 0.1 },
  arcompl: { setup: `goNow('desktop'); AR.done=[true,true,true,true,true]; goNow('arcomplete'); G.screens.arcomplete.t=3.4;`, t: 0.1 },
  arc1:    { setup: `G_arIdx=0; goNow('arcard'); arCardStart(); var L=LEVELS&&0; var s=G.screens.arlevel; var A=ARCH_LEVELS.cipher; s.zones=[]; goNow('arlevel'); A.enter(); A.setScene('l1'); A.sel1=1; for(var i=0;i<40;i++){A.sceneT+=1/60;}`, t: 0.1 },
  arc1b:   { setup: `goNow('arlevel'); ARCH_LEVELS.cipher.enter(); ARCH_LEVELS.cipher.setScene('l2'); ARCH_LEVELS.cipher.tapRow(1); for(var i=0;i<40;i++){ARCH_LEVELS.cipher.sceneT+=1/60;}`, t: 0.1 },
  arc1c:   { setup: `goNow('arlevel'); ARCH_LEVELS.cipher.enter(); ARCH_LEVELS.cipher.setScene('l3'); ARCH_LEVELS.cipher.dial=9; for(var i=0;i<40;i++){ARCH_LEVELS.cipher.sceneT+=1/60;}`, t: 0.1 },
  arc1d:   { setup: `goNow('arlevel'); ARCH_LEVELS.cipher.enter(); ARCH_LEVELS.cipher.setScene('win'); for(var i=0;i<150;i++){ARCH_LEVELS.cipher.sceneT+=1/60;}`, t: 0.1 },
  arc2:    { setup: `G_arIdx=1; startArch(1); var L=ARCH_LEVELS.stars; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc2b:   { setup: `G_arIdx=1; startArch(1); var L=ARCH_LEVELS.stars; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var k=0;k<5;k++){var li=L.stars(); for(var i=0;i<li.length;i++) if(li[i].real && li[i].n===k){L.pick(i);break;}} L.pick(L.stars().findIndex(function(s){return !s.real;})); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc2c:   { setup: `G_arIdx=1; startArch(1); var L=ARCH_LEVELS.stars; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.zoom=1.5; for(var k=0;k<3;k++){var li=L.stars(); for(var i=0;i<li.length;i++) if(li[i].real && li[i].n===k){L.pick(i);break;}} for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc2e:   { setup: `G_arIdx=1; startArch(1); var L=ARCH_LEVELS.stars; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var k=0;k<10;k++){var li=L.stars(); for(var i=0;i<li.length;i++) if(li[i].real && li[i].n===k){L.pick(i);break;}} L.okT=2.6; for(var i=0;i<260;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc3e:   { setup: `G_arIdx=2; startArch(2); var L=ARCH_LEVELS.music; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.setScene('win'); L.okT=2.0; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc2d:   { setup: `G_arIdx=1; startArch(1); var L=ARCH_LEVELS.stars; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var k=0;k<10;k++){var li=L.stars(); for(var i=0;i<li.length;i++) if(li[i].real && li[i].n===k){L.pick(i);break;}} for(var i=0;i<200;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc3:    { setup: `G_arIdx=2; startArch(2); var L=ARCH_LEVELS.music; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.si=1; L.si=2; L.si=0; L.pi=2; L.hit=[2,0,1,0,0,0,0]; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc3b:   { setup: `G_arIdx=2; startArch(2); var L=ARCH_LEVELS.music; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.startRound(2); L.si=4; L.si=0; L.setScene('repeat'); L.pi=3; L.hit=[0,1,2,0,0,0,0]; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc3c:   { setup: `G_arIdx=2; startArch(2); var L=ARCH_LEVELS.music; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.startRound(5); L.si=3; L.si=0; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc3d:   { setup: `G_arIdx=2; startArch(2); var L=ARCH_LEVELS.music; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.startRound(6); L.setScene('win'); L.okT=1.6; L.wi=3; for(var i=0;i<60;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc4:    { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.openDossier(0); L.win.t=1.4; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc4b:   { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<3;i++)L.openDossier(i); L.win=null; L.qIdx=3; L.qT=3; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc4c:   { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<5;i++)L.openDossier(i); L.win=null; L.sawAns=true; L.setScene('verdict'); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc4d:   { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.setScene('quiz'); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc4e:   { setup: `G_arIdx=3; startArch(3); var L=ARCH_LEVELS.case_; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.setScene('win'); L.okT=1.4; for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc5:    { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc5b:   { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); var o=L.want(); L.touch(o[0]); L.touch(o[1]); L.touch(o[3]); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc5c:   { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); var o=L.want(); for(var k=0;k<7;k++)L.touch(o[k]); L.startCycle(2); for(var i=0;i<40;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc5d:   { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); for(var c=0;c<3;c++){L.startCycle(c); var o=L.want(); for(var k=0;k<7;k++)L.touch(o[k]);} for(var i=0;i<120;i++)L.sceneT+=1/60;`, t: 0.1 },
  arc5p:   { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<40;i++)L.sceneT+=1/60; L.photoView=true; L.photoT=0.3;`, t: 0.1 },
  arc5p2:  { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); var o=L.want(); for(var k=0;k<7;k++)L.touch(o[k]); L.startCycle(1); L.layout(); var o2=L.want(); L.touch(o2[0]); for(var i=0;i<40;i++)L.sceneT+=1/60; L.photoView=true; L.photoT=2.0;`, t: 0.1 },
  arc5p3:  { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); for(var c=0;c<2;c++){L.startCycle(c); var o=L.want(); for(var k=0;k<7;k++)L.touch(o[k]);} L.startCycle(2); L.layout(); for(var i=0;i<40;i++)L.sceneT+=1/60; L.photoView=true; L.photoT=2.4;`, t: 0.1 },
  mrest:   { setup: `G.hearts=new Array(NH).fill(false); for(var i=0;i<EP_N;i++)G.hearts[i]=true; MR.room=false; goNow('restored'); var s=G.screens.restored; for(var i=0;i<200;i++)s.t+=1/60; s.shown=true;`, t: 0.1 },
  mroom:   { setup: `MR.seen=[0,0,0]; MR.room=1; goNow('memroom'); var s=G.screens.memroom; for(var i=0;i<40;i++)s.t+=1/60;`, t: 0.1 },
  mroomz:  { setup: `MR.seen=[0,0,0]; MR.room=1; goNow('memroom'); var s=G.screens.memroom; for(var i=0;i<40;i++)s.t+=1/60; s.openPhoto(0); s.tOpen=2.6;`, t: 0.1 },
  mroomz3: { setup: `MR.seen=[0,0,0]; MR.room=1; goNow('memroom'); var s=G.screens.memroom; for(var i=0;i<40;i++)s.t+=1/60; s.openPhoto(2); s.tOpen=2.6;`, t: 0.1 },
  mroomz4: { setup: `MR.seen=[1,1,1]; MR.room=1; goNow('memroom'); var s=G.screens.memroom; for(var i=0;i<40;i++)s.t+=1/60; s.openPhoto(2); s.tOpen=3.2;`, t: 0.1 },
  mroom2:  { setup: `MR.seen=[1,1,1]; MR.room=1; goNow('memroom'); var s=G.screens.memroom; for(var i=0;i<80;i++)s.t+=1/60;`, t: 0.1 },
  achv:  { setup: `ACH.got.add('first');ACH.got.add('arch1');ACH.got.add('dark');goNow('desktop');openAchievements();var w=G.win;w.t=1;w.data.scroll=0;for(var i=0;i<40;i++)w.t+=1/60;`, t: 0.2 },
  achv2: { setup: `ACH.got.add('first');ACH.got.add('arch1');ACH.got.add('dark');ACH.got.add('egg');ACH.got.add('hot');goNow('desktop');openAchievements();var w=G.win;w.t=1.4;for(var i=0;i<60;i++)w.t+=1/60;w.data.scroll=14;`, t: 0.2 },
  readme2:{ setup: `goNow('desktop');var it=G.screens.desktop.icons.filter(function(i){return i.kind==='readme'})[0];G.screens.desktop.launch(it);var w=G.win;w.t=1.4;for(var i=0;i<60;i++)w.t+=1/60;`, t: 0.2 },
  set2:   { setup: `goNow('desktop');openSettings();var w=G.win;w.t=1.4;for(var i=0;i<60;i++)w.t+=1/60;`, t: 0.2 },
  title2: { setup: `goNow('title');`, t: 0.6 },
  dl2:    { setup: `goNow('desktop');openTxtFile('DEV_LOG_04.txt');var w=G.win;w.t=1.4;for(var i=0;i<60;i++)w.t+=1/60;`, t: 0.2 },
  menu2:  { setup: `goNow('desktop');G.win=null;G.screens.desktop.startOpen=true;`, t: 0.6 },
  boutro2:{ setup: `goNow('desktop');G.win=null;startDialog(LEVELS[7].outro);for(var i=0;i<200;i++)G.dialog.chars+=3;`, t: 0.3 },
  achv3:  { setup: `ACH.got.add('first');ACH.got.add('half');ACH.got.add('eight');ACH.got.add('arch1');ACH.got.add('arch5');ACH.got.add('hot');ACH.got.add('dark');ACH.got.add('egg');ACH.got.add('clean');ACH.got.add('print');goNow('desktop');openAchievements();var w=G.win;w.t=1.4;for(var i=0;i<60;i++)w.t+=1/60;`, t: 0.2 },
  rew2:   { setup: `G.hearts=new Array(NH).fill(false);G.level=3;G.screens.reward.t=0.9;G.screens.reward.done=false;winLevel(3);G.screens.reward.t=1.1;NOTE2.left=0;`, t: 0.2 },
  fin2:   { setup: `goNow('finale');G.screens.finale.phase='end';`, t: 0.3 },
  bi:    { setup: `goNow('desktop');G.win=null;startDialog(LEVELS[6].intro);for(var i=0;i<200;i++)G.dialog.chars+=3;`, t: 0.3 },
  bo:    { setup: `goNow('desktop');G.win=null;startDialog(LEVELS[8].outro);for(var i=0;i<200;i++)G.dialog.chars+=3;G.dialog.i=2;`, t: 0.3 },
  bo2:   { setup: `goNow('desktop');G.win=null;startDialog(LEVELS[11].outro);for(var i=0;i<200;i++)G.dialog.chars+=3;G.dialog.i=2;`, t: 0.3 },
  prog2: { setup: `G.hearts=new Array(NH).fill(false);for(var i=0;i<3;i++)G.hearts[i]=true;save();goNow('desktop');G.win=null;G.screens.desktop.openMapWin();var w=G.win;w.t=1.4;for(var i=0;i<60;i++)w.t+=1/60;`, t: 0.2 },
  pause: { setup: `G.level=5;goNow('level');LEVELS[5].enter();G.screens.level.t=0.9;G.screens.level.bpPause=true;`, t: 0.2 },
  rew:  { setup: `G.hearts[0]=true;G.reward={i:2,t:0};goNow('reward');var r=G.screens.reward;for(var i=0;i<120;i++)r.t+=1/60;`, t: 0.1 },
  arcd0b:{ setup: `G_arIdx=0; startArch(0); var s=G.screens.arcard; s.t=1.2;`, t: 0.2 },
  bp1: { setup: `G.level=5;goNow('level');var L=LEVELS[5];L.enter();L.bpHeat=70;L.meter=52;for(var i=0;i<60;i++){L.t+=1/60;}`, t: 0.1 },
  bp2: { setup: `G.level=5;goNow('level');var L=LEVELS[5];L.enter();L.bpHot=5.4;L.meter=64;for(var i=0;i<6;i++)L.bpSparks.push({a:i*0.9,r:L.R+18,sp:30,t:0});for(var i=0;i<40;i++){L.t+=1/60;}`, t: 0.1 },
  bp3: { setup: `G.level=6;goNow('level');var L=LEVELS[6];L.enter();L.bpChain=12;L.meter=70;for(var i=0;i<40;i++)L.t+=1/60;`, t: 0.1 },
  bp4: { setup: `G.level=7;goNow('level');var L=LEVELS[7];L.enter();L.caught=14;L.bpMagT=2.2;L.bpBolt=0.3;for(var i=0;i<40;i++)L.t+=1/60;`, t: 0.1 },
  bp5: { setup: `G.level=8;goNow('level');var L=LEVELS[8];L.enter();for(var i=0;i<80;i++){L.t+=1/60;}`, t: 0.1 },
  bp6: { setup: `G.level=9;goNow('level');var L=LEVELS[9];L.enter();L.bpDash=0.12;L.bpGhost=[{x:L.px-16,t:0},{x:L.px-8,t:0.1}];for(var i=0;i<10;i++)L.t+=1/60;`, t: 0.1 },
  bp7: { setup: `G.level=10;goNow('level');var L=LEVELS[10];L.enter();L.found=2;L.bpPeek=0.5;L.bpForced=[];for(var i=0;i<20;i++)L.t+=1/60;`, t: 0.1 },
  bp8: { setup: `G.level=11;goNow('level');var L=LEVELS[11];L.enter();L.mistakes=1;L.bpErrT=0.6;L.bpScan=2;for(var i=0;i<40;i++)L.t+=1/60;`, t: 0.1 },
  bp9: { setup: `G.level=12;goNow('level');var L=LEVELS[12];L.enter();L.i=18;L.bpWave=1.2;for(var i=0;i<40;i++)L.t+=1/60;`, t: 0.1 },
  fin1:    { setup: `goNow('finale'); var f=G.screens.finale; f.phase='ask1'; f.t=0; f.btn=-1; f.ans=null; for(var i=0;i<90;i++)f.t+=1/60;`, t: 0.1 },
  fin2:    { setup: `goNow('finale'); var f=G.screens.finale; f.phase='ask1'; f.t=0; f.btn=-1; f.ans=null; f.say('ofc'); for(var i=0;i<90;i++)f.t+=1/60;`, t: 0.1 },
  finE1:   { setup: `goNow('finale'); var f=G.screens.finale; f.phase='end'; f.t=0; f.ans='ofc'; for(var i=0;i<120;i++)f.t+=1/60;`, t: 0.1 },
  finE2:   { setup: `goNow('finale'); var f=G.screens.finale; f.phase='end'; f.t=0; f.ans='yes'; for(var i=0;i<120;i++)f.t+=1/60;`, t: 0.1 },
  arcd0:   { setup: `G_arIdx=0; startArch(0); G.screens.arcard.t=9;`, t: 0.1 },
  arc5p:   { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); for(var i=0;i<40;i++)L.sceneT+=1/60; L.photoView=true; L.photoT=0.3;`, t: 0.1 },
  arc5p2:  { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); var o=L.want(); for(var k=0;k<7;k++)L.touch(o[k]); L.startCycle(1); L.layout(); var o2=L.want(); L.touch(o2[0]); for(var i=0;i<40;i++)L.sceneT+=1/60; L.photoView=true; L.photoT=2.0;`, t: 0.1 },
  arc5p3:  { setup: `G_arIdx=4; startArch(4); var L=ARCH_LEVELS.room; G.screens.arlevel.card=0; L.enter(); goNow('arlevel'); L.layout(); for(var c=0;c<2;c++){L.startCycle(c); var o=L.want(); for(var k=0;k<7;k++)L.touch(o[k]);} L.startCycle(2); L.layout(); for(var i=0;i<40;i++)L.sceneT+=1/60; L.photoView=true; L.photoT=2.4;`, t: 0.1 },
  arcd0:   { setup: `G_arIdx=0; startArch(0); G.screens.arcard.t=9;`, t: 0.1 },
  arcd1:   { setup: `G_arIdx=1; startArch(1); G.screens.arcard.t=9;`, t: 0.1 },
  arcd2:   { setup: `G_arIdx=2; startArch(2); G.screens.arcard.t=9;`, t: 0.1 },
  arcd3:   { setup: `G_arIdx=3; startArch(3); G.screens.arcard.t=9;`, t: 0.1 },
  arcd4:   { setup: `G_arIdx=4; startArch(4); G.screens.arcard.t=9;`, t: 0.1 },
  arrew:   { setup: `G_arIdx=1; AR.done=[true,false,false,false,false]; AR.best=[1,2,0,0,0]; AR.tries=[0,1,0,0,0]; goNow('arreward');`, t: 1.2 },
  dialog:  { setup: `G.level=0; startLevel(0);`, t: 1.2 },
  dialog2: { setup: `G.level=0; startLevel(0); G.fails[0]=3; G.dialog.canSkip=true;`, t: 1.2 },
  load:    { setup: `goNow('desktop'); G.pending={type:'level',idx:0,t:0.3}; Win.open('load','ЗАПУСК ШИФР.exe',{w:170,h:56});`, t: 0.4 },

  ep1:     { setup: LV(0) + `LEVELS[0].sh=1;`, t: 1.0 },
  ep1b:    { setup: LV(0) + `LEVELS[0].sh=13;`, t: 1.0 },
  ep2:     { setup: LV(1) + `var L=LEVELS[1];L.beat=3;L.beatT=0.5;L.hit=4;L.combo=4;`, t: 0.6 },
  ep2b:    { setup: LV(1) + `var L=LEVELS[1];L.beat=2;L.beatT=0.3;L.hit=6;L.miss=1;L.msg='ПОЗДНО';L.msgT=.4;`, t: 0.6 },
  ep3:     { setup: LV(2) + `var L=LEVELS[2];L.stop=1;L.seen=[true,false,false];L.left=18;`, t: 1.0 },
  ep4:     { setup: LV(3) + `var L=LEVELS[3];L.cx=4;L.cy=3;L.steps=17;`, t: 1.0 },
  ep5:     { setup: LV(4) + `var L=LEVELS[4];L.done=[true,false,false];L.step=1;L.pick=0;L.err=1;L.msg=2;`, t: 0.8 },

  ruka:    { setup: LV(5), t: 2.2 },
  arythm:  { setup: LV(6), t: 3.0 },
  serdca:  { setup: LV(7), t: 3.0 },
  amaze:   { setup: LV(8), t: 1.5 },
  azont:   { setup: LV(9), t: 3.0 },
  amemori: { setup: LV(10), t: 1.0 },
  acode:   { setup: LV(11), t: 0.6 },
  aprint:  { setup: LV(12), t: 1.0 },

  reward:  { setup: `G.hearts=[true,true,true,true,false,false,false,false,false,false,false,false,false]; G.level=3; winLevel(3);`, t: 0.9 },
  reward8: { setup: HEART_FULL + ` G.level=4; winLevel(4);`, t: 1.2 },
  term:    { setup: `goNow('desktop'); openTerm(); G.win.data.lines.push({t:'Доступные команды: help — справка,',c:'#ffd166'}); G.win.data.lines.push({t:'hearts — статус сердечек, love — магия.',c:'#ffd166'}); G.win.data.cmd='he'; G.win.data.t=0.3;`, t: 0.6 },
  term2:   { setup: `goNow('desktop'); openTerm(); G.win.data.lines=[{t:'Выполнение команды love...',c:'#ff5d8f'},{t:'Предупреждение: уровень нежности зашкаливает!',c:'#a08cc0'},{t:'',c:''}]; G.win.data.cmd='lov'; G.win.data.t=0.3; loveMagic(6); spawnLove(50);`, t: 0.5 },

  finFly:  { setup: `goNow('finale');`, t: 1.6 },
  finFly2: { setup: `goNow('finale');`, t: 3.0 },
  finBeat: { setup: `goNow('finale');`, t: 6.2 },
  finText: { setup: `goNow('finale'); var s=G.screens.finale; s.phase='text'; s.t=2; s.chars=1e9; s.btn=0;`, t: 0.3 },
  finAsk1: { setup: `goNow('finale'); var s=G.screens.finale; s.t=99; s.chars=1e9; s.phase='ask1'; s.t=1.2; s.btn=1;`, t: 0.4 },
  finAsk2: { setup: `goNow('finale'); var s=G.screens.finale; s.phase='ask2'; s.t=1.2; s.btn=2;`, t: 0.4 },
  finScroll:{ setup: `goNow('finale'); var s=G.screens.finale; s.phase='text'; s.t=2; s.chars=1e9; s.btn=0; s.scroll=3; s.maxScroll=5;`, t: 0.3 },
  finEnd:  { setup: `goNow('finale'); var s=G.screens.finale; s.phase='end'; s.t=1.4; s.btn=-1;`, t: 0.6 }
};

const SIZES = { phone: [420, 760], tall: [380, 900], wide: [900, 620] };

(async () => {
  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=swiftshader', '--mute-audio'],
  });
  const only = process.argv.slice(2).filter(a => !a.startsWith('--'));
  const sizeArg = (process.argv.find(a => a.startsWith('--size=')) || '--size=phone').slice(7);
  const [VW, VH] = SIZES[sizeArg] || SIZES.phone;

  const page = await browser.newPage();
  page.on('console', m => { const t = m.text(); if (/error|Error/.test(t)) console.log('PAGE:', t); });
  page.on('pageerror', e => console.log('PAGEERROR:', e.message));
  await page.setViewport({ width: VW, height: VH, deviceScaleFactor: 1 });
  await page.goto(URL, { waitUntil: 'load' });
  await page.waitForFunction('typeof W !== "undefined" && W > 0', { timeout: 15000 });
  await new Promise(r => setTimeout(r, 400));

  const names = only.length ? only : Object.keys(SCENES);
  for (const name of names) {
    const sc = SCENES[name];
    if (!sc) { console.log('нет сцены', name); continue; }
    await page.evaluate(sc.setup + `\nwindow.requestAnimationFrame = function(){ return 0; };`);
    await page.evaluate((t) => {
      const steps = Math.max(1, Math.round(t / (1 / 60)));
      for (let i = 0; i < steps; i++) { const s = G.screens[G.state]; if (s && s.update) s.update(1 / 60); }
      const s = G.screens[G.state]; if (s && s.draw) s.draw();
    }, sc.t);
    const file = path.join(OUT, `${name}-${sizeArg}.png`);
    const data = await page.evaluate(() => cv.toDataURL('image/png'));
    fs.writeFileSync(file, Buffer.from(data.split(',')[1], 'base64'));
    console.log('OK', path.relative(__dirname, file));
  }
  await browser.close();
})().catch(e => { console.error('FAIL', e.stack); process.exit(1); });
