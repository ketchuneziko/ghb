// генератор поля звёзд для АРХИВ 02: сердце (10 точек) + 20 ложных звёзд
function mulberry32(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
const N = 10;
const d = (a,b) => Math.hypot(a[0]-b[0], a[1]-b[1]);
const raw = [];
for(let i=0;i<N;i++){
  const t = (i/N)*Math.PI*2;
  raw.push([16*Math.pow(Math.sin(t),3), 13*Math.cos(t)-5*Math.cos(2*t)-2*Math.cos(3*t)-Math.cos(4*t)]);
}
let mnx=1e9,mxx=-1e9,mny=1e9,mxy=-1e9;
for(const p of raw){ mnx=Math.min(mnx,p[0]); mxx=Math.max(mxx,p[0]); mny=Math.min(mny,p[1]); mxy=Math.max(mxy,p[1]); }
const base = raw.map(p => [ 0.09+0.82*(p[0]-mnx)/(mxx-mnx), 0.08+0.84*(1-(p[1]-mny)/(mxy-mny)) ]);
function margins(all){
  const out = [];
  for(let i=0;i<N;i++){
    const cand = [];
    for(let j=0;j<all.length;j++) if(j!==i) cand.push({j, dd:d(all[i],all[j])});
    cand.sort((a,b)=>a.dd-b.dd);
    out.push({first:cand[0].j, m:cand[1].dd/cand[0].dd});
  }
  return out;
}
let best = null, bestScore = -1;
for(let js=1; js<=400; js++){
  const rj = mulberry32(js*7919);
  const heart = base.map(p => [ p[0]+(rj()-0.5)*0.10, p[1]+(rj()-0.5)*0.10 ]);
  for(let s=1; s<=40; s++){
    const r = mulberry32(s*104729+js);
    const cand = []; let ok = true;
    for(let k=0;k<20;k++){
      let placed = false;
      for(let att=0; att<80; att++){
        const p = [0.03+0.94*r(), 0.04+0.92*r()];
        if(heart.every(h => d(h,p) > 0.08) && cand.every(q => d(q,p) > 0.05)){ cand.push(p); placed = true; break; }
      }
      if(!placed){ ok = false; break; }
    }
    if(!ok) continue;
    const all = [...heart, ...cand];
    const mg = margins(all);
    let good = true, score = 0;
    for(let i=0;i<N;i++){
      if(mg[i].first !== (i+1)%N){ good = false; break; }
      if(mg[i].m < 1.18){ good = false; break; }
      score += Math.min(mg[i].m, 2.2);
    }
    if(good && score > bestScore){ bestScore = score; best = {heart, D:cand, mg}; }
  }
}
if(!best){ console.log('НЕ НАЙДЕНО'); process.exit(1); }
const {heart, D, mg} = best;
console.log('запас:', mg.map(m=>m.m.toFixed(2)).join(' '), ' score', bestScore.toFixed(1));
const f = a => '['+a.map(p=>'['+(+p[0].toFixed(3))+','+(+p[1].toFixed(3))+']').join(',')+']';
console.log('ARC2_STARS_HEART = '+f(heart)+';');
console.log('ARC2_STARS_FAKE  = '+f(D)+';');
const G=60,R=28,g=Array.from({length:R},()=>Array(G).fill(' '));
const put=(x,y,c)=>{const gx=Math.round(x*(G-1)),gy=Math.round(y*(R-1)); if(g[gy])g[gy][gx]=c;};
heart.forEach((p,i)=>put(p[0],p[1],String(i)));
for(let i=0;i<N;i++){const a=heart[i],b=heart[(i+1)%N]; for(let k=0;k<=8;k++) put(a[0]+(b[0]-a[0])*k/8,a[1]+(b[1]-a[1])*k/8,'.');}
D.forEach(p=>put(p[0],p[1],'o'));
console.log(g.map(r=>r.join('').replace(/\s+$/,'')).join('\n'));
