const puppeteer=require('puppeteer');
(async()=>{
  const b=await puppeteer.launch({args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=swiftshader','--mute-audio']});
  const p=await b.newPage(); await p.setViewport({width:420,height:760});
  await p.goto('http://127.0.0.1:8711/index.html',{waitUntil:'load'});
  await p.waitForFunction('typeof W!=="undefined"&&W>0');
  console.log(await p.evaluate(`JSON.stringify({W:W,a:textW('ПОДСКАЗКА',1),b:textW('СБРОС',1),c:textW('СДВИГ',1),d:textW('ОТПРАВИТЬ ♥',1),e:textW('ФРАЗА',1)})`));
  await b.close();
})();
